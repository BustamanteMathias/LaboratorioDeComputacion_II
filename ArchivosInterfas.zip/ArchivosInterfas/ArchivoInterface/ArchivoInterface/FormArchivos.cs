using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Biblioteca;
using System.IO;

namespace ArchivoInterface
{
  public partial class FormArchivos : Form
  {

    public FormArchivos()
    {
      InitializeComponent();
    }

    private void Form1_Load(object sender, EventArgs e)
    {

    }

    private void button2_Click(object sender, EventArgs e)
    {
      if (this.txtUsuario.Text != string.Empty && this.txtMensaje.Text != string.Empty)
      {
        Mensaje m = new Mensaje(this.txtUsuario.Text, this.txtMensaje.Text);
        this.listBox.Items.Add(m.ToString());
      }
      else
      {
        MessageBox.Show("No se permiten campos de USUARIO o MENSAJE vacios");
      }
      
    }

    private void button1_Click(object sender, EventArgs e)
    {

      if (Directory.Exists(Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + "/Registro.txt"))
      {
        StreamWriter archivo = new StreamWriter(Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + "/Registro.txt", true);

        foreach (string item in this.listBox.Items)
        {
          archivo.WriteLine(item.ToString());
        }

        archivo.Close();
        
      }
      else
      {
        StreamWriter archivo = new StreamWriter(Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + "/Registro.txt");

        archivo.WriteLine("        HORA        |USUARIO: MENSAJE\n");

        foreach (string item in this.listBox.Items)
        {
          archivo.WriteLine(item.ToString());
        }

        archivo.Close();
      }

      this.listBox.Items.Clear();
    }
  }
}

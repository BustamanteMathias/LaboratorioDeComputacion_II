using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Biblioteca
{
  public class Mensaje : IMensaje
  {
    private string usuario;
    private string texto;
    private DateTime hora;

    public string Usuario { get => this.usuario; set => this.usuario = value; }
    public string Texto { get => this.texto; set => this.texto = value; }
    public DateTime Hora { get => this.hora; set => this.hora = value; }

    public Mensaje(string user, string msj)
    {
      this.Usuario = user;
      this.Texto = msj;
      this.Hora = DateTime.Now;
    }

    public override string ToString()
    {
      return string.Format("{0} | {1}: {2}", this.Hora, this.Usuario, this.Texto); 
    }
  }
}

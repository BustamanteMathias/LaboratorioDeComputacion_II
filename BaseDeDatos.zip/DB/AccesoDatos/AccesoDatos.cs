﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using DB;

namespace DB
{
    public class AccesoDatos
    {
        private SqlConnection _sqlConnection;   //PARA ESTABLECER CONEXION CON BASE DE DATOS
        private SqlCommand _sqlCommand;         //PARA CONSULTAS
        private List<Persona> _listaPersonas;

        public AccesoDatos()
        {
            this._sqlConnection = new SqlConnection("Data Source=LAB5PC07\\SQLEXPRESS;Integrated Security=True");
            this._listaPersonas = new List<Persona>();
        }

        public List<Persona> TraerTodos()
        {
            this._sqlCommand = new SqlCommand();

            this._sqlCommand.Connection = this._sqlConnection;
            this._sqlCommand.CommandType = CommandType.Text;
            this._sqlCommand.CommandText = "SELECT * FROM Padron.dbo.Personas";

            try
            {
                this._sqlConnection.Open();
                SqlDataReader _sqlDataReader = this._sqlCommand.ExecuteReader();

                while(_sqlDataReader.Read())
                {
                    Persona miPersona = new Persona();
                    miPersona = (Persona)_sqlDataReader[0];
                    this._listaPersonas.Add(miPersona);
                }
                this._sqlConnection.Close();
            }
            catch (Exception)
            {
                throw;
            }

            return this._listaPersonas;
        }

        public bool AgregarPersona( Persona p)
        {
            this._sqlCommand = new SqlCommand();

            this._sqlCommand.Connection = this._sqlConnection;
            this._sqlCommand.CommandType = CommandType.Text;
            this._sqlCommand.CommandText = 
                "INSERT INTO Personas " +
                "nombre, apellido, edad " +
                "values('" + p.nombre + "','" + p.apellido + "',"+p.edad.ToString()+")";
            
            return true;
        }
    }

    public class Persona
    {
        public int id;
        public string nombre;
        public string apellido;
        public int edad;

        public override string ToString()
        {
            return string.Format("ID: {0}\tNOMBRE COMPLETO: {1}, {2}\tEDAD: {3}\n", this.id, this.apellido, this.nombre, this.edad);
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DB;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Persona> listaPersonas;
            DB.AccesoDatos accesoDatos = new DB.AccesoDatos();
            listaPersonas = accesoDatos.TraerTodos();

            foreach (Persona item in listaPersonas)
            {
                Console.Write(item.ToString());
            }
            Console.ReadKey();
        }
    }
}

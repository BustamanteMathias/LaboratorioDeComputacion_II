﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace Entidades
{
    public static class AstroExtension
    {
        public static bool GuardarPlanTxt(this Planeta<Satelite> plan)
        {
            bool rtn = false;
            string pathEscritorio = Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + "\\";

            try
            {
                StreamWriter f = new StreamWriter(pathEscritorio + "planeta.txt", true);
                f.WriteLine(plan);
                f.Close();
                rtn = true;
            }
            catch (Exception e)
            {
                Console.WriteLine("Error en GuardarTXT: " + e.Message);
            }

            return rtn;
        }

        public static bool GuardarXML(this Satelite sat)
        {
            bool rtn = false;
            string pathEscritorio = Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + "\\";
            try
            {
                StreamWriter f = new StreamWriter(pathEscritorio + "satelites.xml");
                f.Write(sat);
                f.Close();
                rtn = true;
            }
            catch (Exception e)
            {
                throw new Exception(e.Message);
            }

            return rtn;
        }
    }
}

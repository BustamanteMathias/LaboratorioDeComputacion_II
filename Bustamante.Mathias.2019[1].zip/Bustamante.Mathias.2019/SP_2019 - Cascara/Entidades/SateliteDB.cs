﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using System.Windows.Forms;

namespace Entidades
{
    public class SateliteDB
    {
        public bool Guardar(Satelite satelite)
        {
            SqlCommand comando = new SqlCommand();
            SqlConnection conexion = new SqlConnection(Properties.Settings.Default.CadenaDeConexion);

            string sqlQuery = "INSERT INTO dbo.Satelites (nombre, duracion_orbita, duracion_rotacion) VALUES ('" + satelite.Nombre + "', '" + satelite.DuraOrbita + "', '"+ satelite.DuraRotacion +"')";


            comando.CommandType = CommandType.Text;
            comando.CommandText = sqlQuery;
            comando.Connection = conexion;

            try
            {
                conexion.Open();
                comando.ExecuteNonQuery();
            }
            catch (InvalidCastException e)
            {
                MessageBox.Show("Error: " + e.Message);
            }
            catch (SqlException e)
            {
                MessageBox.Show("Error: " + e.Message);
            }
            catch (System.IO.IOException e)
            {
                MessageBox.Show("Error: " + e.Message);
            }
            catch (InvalidOperationException e)
            {
                MessageBox.Show("Error: " + e.Message);
            }
            finally
            {
                conexion.Close();
            }

            return true;
        }

        public List<Satelite> Leer()
        {
            List<Satelite> rtn = new List<Satelite>();

            SqlCommand comando = new SqlCommand();
            SqlConnection conexion = new SqlConnection(Properties.Settings.Default.CadenaDeConexion);

            string sqlQuery = "SELECT * FROM planetario.dbo.Satelites";


            comando.CommandType = CommandType.Text;
            comando.CommandText = sqlQuery;
            comando.Connection = conexion;

            try
            {

                SqlDataReader _sqlDataReader = comando.ExecuteReader();

                while (_sqlDataReader.Read())
                {
                    Satelite miSatelite = new Satelite();
                    miSatelite = (Satelite)_sqlDataReader[0];
                    rtn.Add(miSatelite);
                }

                conexion.Open();
                comando.ExecuteNonQuery();
            }
            catch (InvalidCastException e)
            {
                MessageBox.Show("Error: " + e.Message);
            }
            catch (SqlException e)
            {
                MessageBox.Show("Error: " + e.Message);
            }
            catch (System.IO.IOException e)
            {
                MessageBox.Show("Error: " + e.Message);
            }
            catch (InvalidOperationException e)
            {
                MessageBox.Show("Error: " + e.Message);
            }
            finally
            {
                conexion.Close();
            }

            return rtn;
        }
    }
}

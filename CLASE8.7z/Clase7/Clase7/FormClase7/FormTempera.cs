﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using EntidadesPaletaTempera;

namespace FormClase7
{
    public partial class FormTempera : Form
    {
        private Tempera miTempera;

        public Tempera MiTempera
        {
            get { return this.miTempera; }
        }


        public FormTempera()
        {
            InitializeComponent();
        }

        private void Tempera_Load(object sender, EventArgs e)
        {
            //this.BackColor = Color.Azure;
            this.FormBorderStyle = FormBorderStyle.FixedSingle;

            foreach (ConsoleColor item in Enum.GetValues(typeof(ConsoleColor)))
            {
                this.cmbColor.Items.Add(item);
            }
            this.cmbColor.Text = ConsoleColor.Magenta.ToString();
            this.cmbColor.DropDownStyle = ComboBoxStyle.DropDownList;
        }

        private void button1_Click(object sender, EventArgs e)
        {
           
            this.miTempera = new Tempera((ConsoleColor)this.cmbColor.SelectedItem, this.textMarca.Text, int.Parse(this.textCantidad.Text));
            this.DialogResult = DialogResult.OK;
            MessageBox.Show(miTempera);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}

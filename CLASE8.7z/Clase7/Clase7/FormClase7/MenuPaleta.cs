﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using EntidadesPaletaTempera;

namespace FormClase7
{
    public partial class MenuPaleta : Form
    {
        private Paleta miPaleta;
        private Tempera miTempera;

        public MenuPaleta()
        {
            InitializeComponent();
            this.IsMdiContainer = true;
            this.groupBoxPaleta.Visible = false;
            this.StartPosition = FormStartPosition.CenterScreen;
        }

        private void MenuPaleta_Load(object sender, EventArgs e)
        {
            
        }

        private void nuevaTemperaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormTempera frmTempera = new FormTempera();
            //frmTempera.MdiParent = this;
            frmTempera.ShowDialog();
            this.miPaleta += frmTempera.MiTempera;
            //miTempera = frmTempera.MiTempera;

            if (frmTempera.DialogResult == DialogResult.OK)
            {
                string s = (string)this.miPaleta;
                this.listBoxTemperas.Items.Add(s);
            }

        }

        private void nuevaPaletaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            miPaleta = 5;
            //this.menuStrip1.Enabled = false;
            this.groupBoxPaleta.Visible = true;
        }

        private void button2_Click(object sender, EventArgs e)  // BOTON +
        {
            FormTempera frmTempera = new FormTempera();
            frmTempera.ShowDialog();
            this.miPaleta += frmTempera.MiTempera;

            if (frmTempera.DialogResult == DialogResult.OK)
            {
                string s = (string)this.miPaleta;
                this.listBoxTemperas.Items.Add(s);
            }
        }

        private void button1_Click(object sender, EventArgs e)  // BOTON -
        {
            FormTempera frmTempera = new FormTempera();
            frmTempera.ShowDialog();
            this.miPaleta -= frmTempera.MiTempera;

            if (frmTempera.DialogResult == DialogResult.OK)
            {
                string s = (string)this.miPaleta;
                this.listBoxTemperas.Items.Add(s);
            }
        }

        private void listBoxTemperas_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}

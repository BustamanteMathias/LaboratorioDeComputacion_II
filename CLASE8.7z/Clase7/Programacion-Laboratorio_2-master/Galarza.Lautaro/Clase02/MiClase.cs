﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


//miembro de clase (estatico) -- miembro de instancia(no estatico)
namespace ConsoleApp1
{                   //es buena practica siempre poner el modificador
     public class MiClase //cuando una clase es marcada con el signo (-) significa que tiene el modificador de visibilidad private y la publica con el (+)
    {
        public static string nombre ="juan"; // modificador de visibilidad y comportamiento en este caso estatico (static)
        public static int edad=23;      //con ese comportamiento puedo acceder al atributo desde el nombre de su clase

        public static void MostrarEdad()//metodo
        {

            Console.WriteLine( MiClase.edad);


        }

        public static string RetornarNombre()
        {


            return MiClase.nombre;

        }

        public static bool CompararNombres (string nombre)
        {
            bool comparacion=false;

            if(nombre==MiClase.nombre)
            {
                comparacion = true;
            }

            return comparacion;
        }

    }
}

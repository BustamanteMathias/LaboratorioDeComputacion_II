﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Clase_03
{
    class Persona
    {

        public string nombre="";
        public string apellido="";
        public int dni=0;
       


        public string mostrar()
        {
            return this.nombre + "-" + this.apellido + "-" + this.dni.ToString() + "\n";

        }

        public Persona (string nombre, string apellido, int dni)//constructor de instancia
        {
            this.apellido = apellido;
            this.nombre = nombre;
            this.dni = dni;


        }

    }
}

﻿namespace Clase_04.WindowsForm
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lvlEntero = new System.Windows.Forms.Label();
            this.lvlCadena = new System.Windows.Forms.Label();
            this.lvlFecha = new System.Windows.Forms.Label();
            this.txtCadena = new System.Windows.Forms.TextBox();
            this.txtFecha = new System.Windows.Forms.TextBox();
            this.txtEntero = new System.Windows.Forms.TextBox();
            this.btnCrear = new System.Windows.Forms.Button();
            this.lstMostrar = new System.Windows.Forms.ListBox();
            this.btnRojo = new System.Windows.Forms.Button();
            this.btnNegro = new System.Windows.Forms.Button();
            this.btnAzul = new System.Windows.Forms.Button();
            this.btnDefault = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lvlEntero
            // 
            this.lvlEntero.AutoSize = true;
            this.lvlEntero.Location = new System.Drawing.Point(37, 53);
            this.lvlEntero.Name = "lvlEntero";
            this.lvlEntero.Size = new System.Drawing.Size(38, 13);
            this.lvlEntero.TabIndex = 0;
            this.lvlEntero.Text = "Entero";
            this.lvlEntero.Click += new System.EventHandler(this.label1_Click);
            // 
            // lvlCadena
            // 
            this.lvlCadena.AutoSize = true;
            this.lvlCadena.Location = new System.Drawing.Point(37, 79);
            this.lvlCadena.Name = "lvlCadena";
            this.lvlCadena.Size = new System.Drawing.Size(44, 13);
            this.lvlCadena.TabIndex = 0;
            this.lvlCadena.Text = "Cadena";
            this.lvlCadena.Click += new System.EventHandler(this.label1_Click);
            // 
            // lvlFecha
            // 
            this.lvlFecha.AutoSize = true;
            this.lvlFecha.Location = new System.Drawing.Point(38, 105);
            this.lvlFecha.Name = "lvlFecha";
            this.lvlFecha.Size = new System.Drawing.Size(37, 13);
            this.lvlFecha.TabIndex = 0;
            this.lvlFecha.Text = "Fecha";
            this.lvlFecha.Click += new System.EventHandler(this.label1_Click);
            // 
            // txtCadena
            // 
            this.txtCadena.Location = new System.Drawing.Point(120, 76);
            this.txtCadena.Name = "txtCadena";
            this.txtCadena.Size = new System.Drawing.Size(100, 20);
            this.txtCadena.TabIndex = 1;
            // 
            // txtFecha
            // 
            this.txtFecha.Location = new System.Drawing.Point(120, 102);
            this.txtFecha.Name = "txtFecha";
            this.txtFecha.Size = new System.Drawing.Size(100, 20);
            this.txtFecha.TabIndex = 2;
            // 
            // txtEntero
            // 
            this.txtEntero.Location = new System.Drawing.Point(120, 50);
            this.txtEntero.Name = "txtEntero";
            this.txtEntero.Size = new System.Drawing.Size(100, 20);
            this.txtEntero.TabIndex = 3;
            // 
            // btnCrear
            // 
            this.btnCrear.Location = new System.Drawing.Point(40, 239);
            this.btnCrear.Name = "btnCrear";
            this.btnCrear.Size = new System.Drawing.Size(180, 36);
            this.btnCrear.TabIndex = 4;
            this.btnCrear.Text = "Crear";
            this.btnCrear.UseVisualStyleBackColor = true;
            this.btnCrear.Click += new System.EventHandler(this.btnCrear_Click);
            // 
            // lstMostrar
            // 
            this.lstMostrar.FormattingEnabled = true;
            this.lstMostrar.Location = new System.Drawing.Point(40, 128);
            this.lstMostrar.Name = "lstMostrar";
            this.lstMostrar.Size = new System.Drawing.Size(180, 95);
            this.lstMostrar.TabIndex = 5;
            this.lstMostrar.SelectedIndexChanged += new System.EventHandler(this.lstList_SelectedIndexChanged);
            // 
            // btnRojo
            // 
            this.btnRojo.Location = new System.Drawing.Point(6, 293);
            this.btnRojo.Name = "btnRojo";
            this.btnRojo.Size = new System.Drawing.Size(75, 23);
            this.btnRojo.TabIndex = 6;
            this.btnRojo.Text = "Rojo";
            this.btnRojo.UseVisualStyleBackColor = true;
            this.btnRojo.Click += new System.EventHandler(this.btnRojo_Click);
            // 
            // btnNegro
            // 
            this.btnNegro.Location = new System.Drawing.Point(87, 293);
            this.btnNegro.Name = "btnNegro";
            this.btnNegro.Size = new System.Drawing.Size(75, 23);
            this.btnNegro.TabIndex = 7;
            this.btnNegro.Text = "Negro";
            this.btnNegro.UseVisualStyleBackColor = true;
            this.btnNegro.Click += new System.EventHandler(this.button2_Click);
            // 
            // btnAzul
            // 
            this.btnAzul.Location = new System.Drawing.Point(171, 293);
            this.btnAzul.Name = "btnAzul";
            this.btnAzul.Size = new System.Drawing.Size(75, 23);
            this.btnAzul.TabIndex = 8;
            this.btnAzul.Text = "Azul";
            this.btnAzul.UseVisualStyleBackColor = true;
            this.btnAzul.Click += new System.EventHandler(this.btnAzul_Click);
            // 
            // btnDefault
            // 
            this.btnDefault.Location = new System.Drawing.Point(6, 12);
            this.btnDefault.Name = "btnDefault";
            this.btnDefault.Size = new System.Drawing.Size(75, 27);
            this.btnDefault.TabIndex = 9;
            this.btnDefault.Text = "Restablecer";
            this.btnDefault.UseVisualStyleBackColor = true;
            this.btnDefault.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(251, 328);
            this.Controls.Add(this.btnDefault);
            this.Controls.Add(this.btnAzul);
            this.Controls.Add(this.btnNegro);
            this.Controls.Add(this.btnRojo);
            this.Controls.Add(this.lstMostrar);
            this.Controls.Add(this.btnCrear);
            this.Controls.Add(this.txtEntero);
            this.Controls.Add(this.txtFecha);
            this.Controls.Add(this.txtCadena);
            this.Controls.Add(this.lvlFecha);
            this.Controls.Add(this.lvlCadena);
            this.Controls.Add(this.lvlEntero);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "Form1";
            this.Text = "Clase_04";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lvlEntero;
        private System.Windows.Forms.Label lvlCadena;
        private System.Windows.Forms.Label lvlFecha;
        private System.Windows.Forms.TextBox txtCadena;
        private System.Windows.Forms.TextBox txtFecha;
        private System.Windows.Forms.TextBox txtEntero;
        private System.Windows.Forms.Button btnCrear;
        private System.Windows.Forms.ListBox lstMostrar;
        private System.Windows.Forms.Button btnRojo;
        private System.Windows.Forms.Button btnNegro;
        private System.Windows.Forms.Button btnAzul;
        private System.Windows.Forms.Button btnDefault;
    }
}


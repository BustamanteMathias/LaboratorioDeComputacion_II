﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Clase_04.Entidades;

namespace Clase_04.WindowsForm
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnCrear_Click(object sender, EventArgs e)
        {
            int entero = int.Parse(this.txtEntero.Text);
            string cadena = this.txtCadena.Text;
            DateTime fecha = Convert.ToDateTime(this.txtFecha.Text);

            Cosa MiCosa = new Cosa(cadena, fecha, entero);

            //MessageBox.Show(MiCosa.Mostrar());

            //MessageBox.Show("Entero: " + entero + "Cadena:" + "Fecha: " + fecha + "\n");

            MessageBox.Show(MiCosa.Mostrar(), "MENSAJE EXITOSO", MessageBoxButtons.OK,MessageBoxIcon.Asterisk);
          
            lstMostrar.Items.Add(MiCosa.Mostrar());

        }

        private void Form1_Load(object sender, EventArgs e)
        {
        }

        private void lstList_SelectedIndexChanged(object sender, EventArgs e)
        {
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.BackColor = Color.Black;
            this.ForeColor = Color.White;
        }

        private void btnRojo_Click(object sender, EventArgs e)
        {
            this.BackColor = Color.Red;
            this.ForeColor = Color.Black;


        }

        private void btnAzul_Click(object sender, EventArgs e)
        {
            this.BackColor = Color.Blue;
            this.ForeColor = Color.Black;
        }

        private void progressBar1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.BackColor = Color.Empty;
            this.ForeColor = Color.Black;

        }
    }
}

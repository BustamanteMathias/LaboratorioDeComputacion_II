﻿

public enum EtipoTinta // creo los datos enumerados
	{
	    comun,
        china,
        conBrillito

	}
﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Clase_05.Entidades
{
    public class Pluma
    {
        private string _marca;
        private int _cantidad;
        private Tinta _tinta;

        public Pluma()
        {
            this._cantidad = 0;
            this._marca = "Sin Marca";
            this._tinta = null;

        }
        public Pluma(string marca) : this()
        {
            this._marca = marca;

        }
        public Pluma(string marca, int cantidad) : this(marca)
        {
            this._cantidad = cantidad;
        }
        public Pluma(Tinta MiTinta, string marca, int cantidad) : this(marca, cantidad)
        {
            this._tinta = MiTinta;

        }
        
        private string mostrar ()//de instancia
        {

             return "cantidad: " + this._cantidad.ToString() + " - " + "marca: " + this._marca.ToString() + " - " + "Tinta: " + Tinta.Mostrar(this._tinta);

        }
        public static implicit operator string (Pluma miPluma)
        {
            return miPluma.mostrar();
        }

        public static bool operator ==(Pluma pluma1, Tinta tinta1)
        {

            return (pluma1 == tinta1);//estoy invovcando al operador sobrecardo de antes ya que recive los mismos tipos de parametros

        }

        public static bool operator !=(Pluma pluma1, Tinta tinta1) 
        {

            return !(pluma1 == tinta1);

        }

         public static Pluma operator + (Pluma pluma1, Tinta tinta1)
        {
            //int cantidades;
            if(pluma1._tinta==tinta1 && pluma1._cantidad<100)
            {
                pluma1._cantidad++;

            }

            return pluma1;
            
        }

    }
}

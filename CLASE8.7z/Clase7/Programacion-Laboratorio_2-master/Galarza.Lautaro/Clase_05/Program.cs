﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Clase_05.Entidades;

namespace Clase_05
{
    class Program
    {
        static void Main(string[] args)
        {
            Tinta tintaUno = new Tinta();
            Tinta tintaDos = new Tinta(EtipoTinta.china, ConsoleColor.DarkGreen);
            Tinta tintaTres = new Tinta(EtipoTinta.china, ConsoleColor.DarkGreen);
            Pluma plumaUno = new Pluma(tintaDos, "faber", 21);

            plumaUno += tintaTres;

            String cadenaTinta = (string)tintaUno;
            String cadenaPluma = (string)plumaUno;

            //Console.WriteLine(cadenaTinta);
            Console.WriteLine(cadenaPluma);



            Console.ReadLine();


        }
    }
}

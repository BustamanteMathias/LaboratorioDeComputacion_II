﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_02
{
    class Program
    {
        static void Main(string[] args)
        {
            int numero;
            double cubo;
            double cuadrado;

            Console.Title = "Ejercicio 02";

            Console.WriteLine("Ingrese un numero:");

            numero = int.Parse(Console.ReadLine());


            while (numero <= 0)
            {
                Console.Write("ERROR. Ingrese un numero entero positivo: ");
                numero = int.Parse(Console.ReadLine());
            }

            cubo = Math.Pow(numero, 3);
            cuadrado = Math.Pow(numero, 2);

            Console.WriteLine("el cuadrado del numero es: {0}", cuadrado);
            Console.WriteLine("el cubo del numero es: {0}", cubo);

        }
    }
}

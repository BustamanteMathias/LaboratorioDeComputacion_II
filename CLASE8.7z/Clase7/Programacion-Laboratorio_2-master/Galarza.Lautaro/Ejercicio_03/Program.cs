﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_03
{
    class Program
    {
        static void Main(string[] args)
        {
            int numero;
            int i;
            int contador = 0;

            Console.Title = "Ejercicio_03";

            Console.Write("Ingrese un numero y se buscaran los numeros primos hasta el ingresado:");

            numero = int.Parse(Console.ReadLine());


            while (numero <= 1)
            {
                Console.Write("ERROR. Ingrese un numero mayor a 1: ");
                numero = int.Parse(Console.ReadLine());
            }

            for (i = 2; i <= numero; i++)
            {

                for (int j = 1; j <= i; j++)
                {

                    if (i % j == 0)
                    {
                        contador++;
                    }


                }

                if (contador == 2)
                {
                    Console.Write("  ");
                    Console.Write(i);
                }

                contador = 0;

            }

            Console.ReadKey();

        }
    }
}

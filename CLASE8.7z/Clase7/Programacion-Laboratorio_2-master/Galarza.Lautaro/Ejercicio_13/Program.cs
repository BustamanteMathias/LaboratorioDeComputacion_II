﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_13
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "EjercicioNro_13";



           Double NumDecimal=8;

            string NumBinario;

            NumBinario = Coversor.DecimalBinario(NumDecimal);

            Console.WriteLine(NumBinario);

            NumDecimal = Coversor.BinarioDecimal(NumBinario);

            Console.WriteLine(NumDecimal);

            Console.ReadLine();



           
            
           
        }
    }
}

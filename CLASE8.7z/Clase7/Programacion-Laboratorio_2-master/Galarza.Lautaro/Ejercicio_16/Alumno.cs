﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_16
{
    class Alumno
    {
         byte nota1=0;
         byte nota2=0;
        float notaFinal=0;
        public string apellido="";
        public int legajo=0;
        public string nombre="";
        static Random notaRandom = new Random();//instacio el objeto de la clase 


        public void Estudiar(byte notaUno, byte notaDos)
        {
            nota1 = notaUno;

            nota2 = notaDos;
        }

        public void CalcularFinal()
        {

            if(this.nota1 >= 4 && this.nota2 >=4 )
            {
                this.notaFinal = (float)notaRandom.Next(1,10); //le paso los parametros 
            }
            else
            {
                this.notaFinal = -1;
            }



        }

        public string Mostrar()
        {


            if (this.notaFinal != -1)
            {
                return "Alumno: " + this.nombre + " " + this.apellido + " - " + "legajo: " + this.legajo + " - " + "Nota 1: " + this.nota1 + " - " + "Nota 2: " + this.nota2 + " - " + "Nota final: " + this.notaFinal.ToString() + "\n";
            }
            else
            {
                return "Alumno: " + this.nombre + " " + this.apellido + " - " + "legajo: " + this.legajo + " - " + "Nota 1: " + this.nota1 + " - " + "Nota 2: " + this.nota2 + " - " + " Alumno desaprobado" + "\n";
            }


        }


    }
}

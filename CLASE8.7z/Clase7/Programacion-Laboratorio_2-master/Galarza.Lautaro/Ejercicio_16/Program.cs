﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_16
{
    class Program
    {
        static void Main(string[] args)
        {

            Console.Title = "Ejercicio 16";

            Alumno AlumnoUno = new Alumno();
            Alumno AlumnoDos = new Alumno();
            Alumno AlumnoTres = new Alumno();

            AlumnoUno.nombre = "Juan";
            AlumnoUno.apellido = "juanes";
            AlumnoUno.legajo = 101;


            AlumnoDos.nombre = "Elvis";
            AlumnoDos.apellido = "Cochuelo";
            AlumnoDos.legajo = 102;


            AlumnoTres.nombre = "Pipo";
            AlumnoTres.apellido = "Pipolines";
            AlumnoTres.legajo = 103;

               ///////////////////////////////////////////////////////////////////

            AlumnoUno.Estudiar(5, 3);
            AlumnoUno.CalcularFinal();
            Console.WriteLine(AlumnoUno.Mostrar());

            AlumnoDos.Estudiar(7, 4);
            AlumnoDos.CalcularFinal();
            Console.WriteLine(AlumnoDos.Mostrar());

            AlumnoTres.Estudiar(4, 4);
            AlumnoTres.CalcularFinal();
            Console.WriteLine(AlumnoTres.Mostrar());


            Console.ReadLine();


        }
    }
}

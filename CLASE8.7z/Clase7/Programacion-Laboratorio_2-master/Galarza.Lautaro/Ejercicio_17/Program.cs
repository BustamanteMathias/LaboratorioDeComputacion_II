﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Ejercicio_Boligrafo;

namespace Ejercicio_17
{
    class Program
    {
        static void Main(string[] args)
        {

            Console.Title = "Ejercicio_17";

            string impresion;
            ConsoleColor colorActual  = Console.ForegroundColor;

            Boligrafo BoligrafoAzul = new Boligrafo(100, ConsoleColor.Blue);
            Boligrafo BoligrafoRojo = new Boligrafo(3, ConsoleColor.Red);



            if (BoligrafoAzul.Pintar(30, out impresion) == true)
            {
                Console.ForegroundColor = BoligrafoAzul.GetColor();
                Console.WriteLine("Gasto de tinta {0}", impresion);
                Console.ForegroundColor = colorActual;
            }
           


            if (BoligrafoRojo.Pintar(30,out impresion) == true)
            {
                Console.ForegroundColor = BoligrafoRojo.GetColor();
                Console.WriteLine("Gasto de tinta {0}", impresion);
                BoligrafoRojo.Recargar();
                Console.ForegroundColor = colorActual;
            }

            /*if (BoligrafoRojo.Pintar(50, out impresion) == true)
            {
                Console.ForegroundColor = BoligrafoRojo.GetColor();
                Console.WriteLine("Gasto de tinta {0}", impresion);
                BoligrafoRojo.Recargar();
                Console.ForegroundColor = colorActual;
            }*/





            Console.ReadLine(); 





        }
    }
}

﻿using Clase25;
public delegate void DelegadoSueldo(Empleado e, float sueldo);
public delegate void DelSueldo(EmpleadoMejorado empMejoado, EmpleadoSueldoArgs empSueldoArg);
//public event DelegadoSueldo
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Clase25
{
    public class EmpleadoSueldoArgs
    {
        private float _sueldo;

        public float Sueldo
        {
            get { return this._sueldo; }
            set { this._sueldo = value; }
        }

    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Clase25;

namespace Consola
{
    class Program
    {
        static void Main(string[] args)
        {
            Empleado e = new Empleado();
            e._limiteSueldo += new DelegadoSueldo(LimiteEmpleadoSueldo);
            e.Nombre = "Carlos";
            e.Legajo = 100;
            e.Sueldo = 12001;
            
            //e._limiteSueldo += 
            Console.WriteLine(e.ToString());

            Console.ReadKey();
        }
        private static void LimiteEmpleadoSueldo(Empleado e, float sueldo)
        {
            Console.WriteLine("{0}{1}\nSe le quiso asignar un sueldo de: {2:.00}", e.Legajo, e.Nombre, e.Sueldo);
        }
    }
}

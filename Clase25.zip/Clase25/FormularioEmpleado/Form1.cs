﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Clase25;

namespace FormularioEmpleado
{
    public partial class Form1 : Form
    {
        public enum Manejador
        {
            LimiteSueldo, Log, Ambos
        }

        Empleado empleado = new Empleado();

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.label1.Text = "Legajo";
            this.label2.Text = "Nombre";
            this.label3.Text = "Sueldo";
            this.label4.Text = "Manejador";
            this.button1.Text = "Generar";
            this.comboBox1.Text = "Log";
            this.comboBox1.Items.Add(Manejador.LimiteSueldo);
            this.comboBox1.Items.Add(Manejador.Log);
            this.comboBox1.Items.Add(Manejador.Ambos);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            empleado.Legajo = int.Parse(this.textBox1.Text);
            empleado.Nombre = this.textBox2.Text;
            empleado.Sueldo = float.Parse(this.textBox3.Text);

            switch (int.Parse(this.comboBox1.ToString()))
            {
                case 0:
                    MessageBox.Show(e.ToString() + "0");
                    break;
                case 1:
                    MessageBox.Show(e.ToString() + "1");
                    break;
                case 2:
                    MessageBox.Show(e.ToString() + "2");
                    break;
            }
        }
    }
}

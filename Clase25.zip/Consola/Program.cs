using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entidades.Alumnos;
using Entidades.Externa;

namespace Consola
{
  class Program
  {
    static void Main(string[] args)
    {
      MiPersona p = new MiPersona("Mathias", "Bustamante", 25, Entidades.Alumnos.ESexo.Masculino);
    }
  }
}

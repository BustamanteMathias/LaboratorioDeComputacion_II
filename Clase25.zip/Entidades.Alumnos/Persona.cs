using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades.Alumnos
{
    public class Persona
    {
        protected string _nombre;
        protected string _apellido;
        protected int _edad;
        protected ESexo _sexo;

        public Persona(string nombre, string apellido, int edad, ESexo sexo)
        {
            this._nombre = nombre;
            this._apellido = apellido;
            this._edad = edad;
            this._sexo = sexo;
        }

    }

  public class MiPersona : Persona
  {
    private string nombre;
    private string apellido;
    private int edad;
    private ESexo sexo;

    public MiPersona(string nombre, string apellido, int edad, ESexo sexo) : base(nombre, apellido, edad, sexo)
    {
      this._nombre = nombre;
      this._apellido = apellido;
      this._edad = edad;
      this._sexo = sexo;
    }

    public string Nombre
    {
      get { return this.nombre; }
      set { this.nombre = value; }
    }
    public string Apellido
    {
      get { return this.apellido; }
      set { this.apellido = value; }
    }
    public int Edad
    {
      get { return this.edad; }
      set { this.edad = value; }
    }
    public ESexo Sexo
    {
      get { return this.sexo; }
      set { this.sexo = value; }
    }

  }

  public static class PersonaExtensora
  {
    public static void Nombre()
    {

    }
  }
}

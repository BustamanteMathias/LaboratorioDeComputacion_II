﻿namespace FormClase7
{
    partial class MenuPaleta
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.administrarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.paletaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.temperaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.nuevaTemperaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.nuevaPaletaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.groupBoxPaleta = new System.Windows.Forms.GroupBox();
            this.listBoxTemperas = new System.Windows.Forms.ListBox();
            this.menuStrip1.SuspendLayout();
            this.groupBoxPaleta.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.administrarToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(672, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // administrarToolStripMenuItem
            // 
            this.administrarToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.paletaToolStripMenuItem,
            this.temperaToolStripMenuItem});
            this.administrarToolStripMenuItem.Name = "administrarToolStripMenuItem";
            this.administrarToolStripMenuItem.Size = new System.Drawing.Size(81, 20);
            this.administrarToolStripMenuItem.Text = "Administrar";
            // 
            // paletaToolStripMenuItem
            // 
            this.paletaToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.nuevaPaletaToolStripMenuItem});
            this.paletaToolStripMenuItem.Name = "paletaToolStripMenuItem";
            this.paletaToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.paletaToolStripMenuItem.Text = "Paleta";
            // 
            // temperaToolStripMenuItem
            // 
            this.temperaToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.nuevaTemperaToolStripMenuItem});
            this.temperaToolStripMenuItem.Name = "temperaToolStripMenuItem";
            this.temperaToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.temperaToolStripMenuItem.Text = "Tempera";
            // 
            // nuevaTemperaToolStripMenuItem
            // 
            this.nuevaTemperaToolStripMenuItem.Name = "nuevaTemperaToolStripMenuItem";
            this.nuevaTemperaToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.nuevaTemperaToolStripMenuItem.Text = "Nueva Tempera";
            this.nuevaTemperaToolStripMenuItem.Click += new System.EventHandler(this.nuevaTemperaToolStripMenuItem_Click);
            // 
            // nuevaPaletaToolStripMenuItem
            // 
            this.nuevaPaletaToolStripMenuItem.Name = "nuevaPaletaToolStripMenuItem";
            this.nuevaPaletaToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.nuevaPaletaToolStripMenuItem.Text = "Nueva Paleta";
            this.nuevaPaletaToolStripMenuItem.Click += new System.EventHandler(this.nuevaPaletaToolStripMenuItem_Click);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(61, 4);
            // 
            // groupBoxPaleta
            // 
            this.groupBoxPaleta.Controls.Add(this.listBoxTemperas);
            this.groupBoxPaleta.Location = new System.Drawing.Point(350, 27);
            this.groupBoxPaleta.Name = "groupBoxPaleta";
            this.groupBoxPaleta.Size = new System.Drawing.Size(322, 267);
            this.groupBoxPaleta.TabIndex = 2;
            this.groupBoxPaleta.TabStop = false;
            this.groupBoxPaleta.Text = "Paleta";
            // 
            // listBoxTemperas
            // 
            this.listBoxTemperas.FormattingEnabled = true;
            this.listBoxTemperas.Location = new System.Drawing.Point(6, 33);
            this.listBoxTemperas.Name = "listBoxTemperas";
            this.listBoxTemperas.Size = new System.Drawing.Size(304, 225);
            this.listBoxTemperas.TabIndex = 0;
            // 
            // MenuPaleta
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(672, 287);
            this.Controls.Add(this.groupBoxPaleta);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "MenuPaleta";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.MenuPaleta_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.groupBoxPaleta.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem administrarToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem paletaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem nuevaPaletaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem temperaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem nuevaTemperaToolStripMenuItem;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.GroupBox groupBoxPaleta;
        private System.Windows.Forms.ListBox listBoxTemperas;
    }
}


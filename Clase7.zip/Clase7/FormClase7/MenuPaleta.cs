﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Clase_06.Entidades;

namespace FormClase7
{
    public partial class MenuPaleta : Form
    {
        private Paleta miPaleta;
        private Tempera miTempera;

        public MenuPaleta()
        {
            InitializeComponent();
            this.IsMdiContainer = true;
            this.groupBoxPaleta.Visible = false;
            this.StartPosition = FormStartPosition.CenterScreen;
        }

        private void MenuPaleta_Load(object sender, EventArgs e)
        {
            
        }

        private void nuevaTemperaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormTempera frmTempera = new FormTempera();
            //frmTempera.MdiParent = this;
            frmTempera.ShowDialog();

            miTempera = frmTempera.MiTempera;

            if(frmTempera.DialogResult == DialogResult.OK)
            {
                string s = miTempera;
                this.listBoxTemperas.Items.Add(s);
            }

        }

        private void nuevaPaletaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            miPaleta = 5;
            //this.menuStrip1.Enabled = false;
            this.groupBoxPaleta.Visible = true;
        }
    }
}

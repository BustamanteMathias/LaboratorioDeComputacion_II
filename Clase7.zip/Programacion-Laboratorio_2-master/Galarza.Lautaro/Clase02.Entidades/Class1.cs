﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Clase02.Entidades
{
    public class Sello
    {

        public static string mensaje;
        public static ConsoleColor color;

        public static string Imprimir()
        {
            Sello.ArmarFormatoMensaje();
            return Sello.mensaje;
        }

        public static void Borrar()
        {
            Sello.mensaje = "---";

        }

        public static void ImprimirEnColor()
        {
            Console.ForegroundColor = color;

            Sello.ArmarFormatoMensaje();
            Sello.color = ConsoleColor.Gray;
            Console.ForegroundColor = color;
        }

        private static string ArmarFormatoMensaje()
        {
            int largo;
            string forma = "*";
            int i;
            largo = Sello.mensaje.Length;

            for (i = 0; i < largo + 2; i++)
            {
                Console.Write(forma);
            }
            Console.Write("\n*" + Sello.mensaje + "*\n");
            for (i = 0; i < largo + 2; i++)
            {
                Console.Write(forma);
            }
            Console.WriteLine("");
            return forma;
        }

    }



           
            
        


}

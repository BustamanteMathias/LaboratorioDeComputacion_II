﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MiLibreria;
using Clase02.Entidades;

namespace ConsoleApp1
{
    class program
    {
        static void Main(string[] args)
        {

            Console.Title = "Clase_02";
            /* string nombre;
             int edad;
             bool comparacion;

             MiClase.MostrarEdad();

             Console.WriteLine(MiClase.RetornarNombre());

             comparacion=MiClase.CompararNombres("juan");

             if(comparacion==true)
             {
                 Console.WriteLine("son iguales");
             }

             Console.WriteLine(MiLibreria.MiClase.MostrarNombre());*/

            Sello.mensaje = "hola mundo";

            Sello.Imprimir();


            Sello.color = ConsoleColor.Red;
            Sello.ImprimirEnColor();

            Sello.Imprimir();


            Sello.Borrar();
            Sello.Imprimir();
            


            Console.ReadLine();



            

        }
    }
}

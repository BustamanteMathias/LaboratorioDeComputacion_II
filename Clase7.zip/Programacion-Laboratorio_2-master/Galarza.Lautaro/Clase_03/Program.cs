﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Clase_03
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Clase_03";

            Persona miPersona = new Persona("Elvis", "Cochuelo", 19809734); //crear objeto y asignarle memoria
            Persona otraPersona = new Persona("Lautaro","Galarza",40950771);

           /* miPersona.nombre = "juansito";
            miPersona.apellido = "perez";
            miPersona.dni = 40950771;*/



            Console.WriteLine(miPersona.mostrar());


            /*miPersona.nombre = "Elvis";
            miPersona.apellido = "Cochuelo";
            miPersona.dni = 39087654;*/

            Console.WriteLine(otraPersona.mostrar());

            Console.ReadLine();

        }
    }
}

﻿using System;

namespace Clase_04.Entidades
{
    public class Cosa
    {
         int miEntero;
         string miCadena;
         DateTime miFecha;


        public Cosa ()
        {
            this.miEntero = -1;
            this.miCadena = "----";
            this.miFecha = DateTime.Now;
        }

        public Cosa(string cadena) : this() //solo para los metodos tipo constructor puedo ejecutar una sobrecarga especial usando los :
        {                                 //de esta forma reutilizo el codigo
            //this.entero = -1;
            //this.fecha = DateTime.Now;
            this.miCadena = cadena;
        }

        public Cosa(string cadena, DateTime fecha) : this( cadena)//llamo al metodo anterior que a su vez llamo al primer constructor
        {
            //this.miCadena = cadena;
            //this.miEntero = -1;
            this.miFecha = fecha;

        }

        public Cosa(string cadena, DateTime fecha, int entero):this(cadena,fecha)//voy llamando al metodo que a su vez llama al otro metodo reutilizando el codigo
        {
            this.miEntero = entero;
            //this.miCadena = cadena;
            //this.miFecha = fecha;

        }


        public string Mostrar()
        {
            return this.miEntero.ToString() + "\n" + this.miFecha.ToString() + "\n" + this.miCadena + "\n";
        }

        public void EstablecerValor (int entero)
        {
            this.miEntero = entero;
        }

        public void EstablecerValor(string cadena)
        {
            this.miCadena = cadena;
        }

        public void EstablecerValor(DateTime fecha)
        {
            this.miFecha = fecha;
        }

    }
}

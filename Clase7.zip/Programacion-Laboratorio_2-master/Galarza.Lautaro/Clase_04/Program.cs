﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Clase_04.Entidades;

namespace Clase_04
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Clase_04";

            DateTime fecha = new DateTime(2018, 12, 9);


            Cosa MiCosa = new Cosa();
            Cosa MiCosaUno = new Cosa("Lautaro");
            Cosa MiCosaDos = new Cosa("Lautaro", fecha);
            Cosa MiCosaTres = new Cosa("Lautaro", fecha, 20);

            Console.WriteLine(MiCosa.Mostrar());
            Console.WriteLine(MiCosaUno.Mostrar());
            Console.WriteLine(MiCosaDos.Mostrar());
            Console.WriteLine(MiCosaTres.Mostrar());

            Console.ReadLine();

        }
    }
}

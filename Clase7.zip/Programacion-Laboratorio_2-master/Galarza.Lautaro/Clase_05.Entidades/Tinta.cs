﻿using System;

namespace Clase_05.Entidades
{
    public class Tinta
    {

        private ConsoleColor _color;

        private EtipoTinta _tipo;//enumerado propio creado por nosotros 
        
        public Tinta ()
        {
            this._color = ConsoleColor.Blue;
            this._tipo = EtipoTinta.comun;

        }

        public Tinta(ConsoleColor color):this()
        {
            this._color = color;
        }

        public Tinta(EtipoTinta tinta , ConsoleColor color) : this(color)
        {
            this._tipo = tinta;
            this._color = color;
        }

        private string Mostrar()
        {
            return "color: "+this._color.ToString()+" - "+"tinta: "+this._tipo.ToString();
        }

        public static string Mostrar(Tinta verTinta)
        {
            return verTinta.Mostrar();
        }

        public static bool operator ==(Tinta tinta1, Tinta tinta2)//esta siempre va a ser la misma firma para la sobrecarga de operadores
        {
          

            if (!object.Equals(tinta1, null) && !object.Equals(tinta2, null))
            {

                return (tinta1._color == tinta2._color && tinta1._tipo == tinta2._tipo); // mis objetos van a ser igual si el color y la tinta son iguales
               //esto va a devolver true si todos esos atributos son iguales

            }
            else
            {
                if( object.Equals(tinta1, null) && object.Equals(tinta2, null)  )
                    {
                    return true;
                }
                else
                {
                    return false;
                }
            }


          

        }

        public static bool operator !=(Tinta Primero, Tinta Segundo) //invoco el == sobrecargado y lo niego
        {   

            return !(Primero==Segundo);

        }

        public static bool operator ==(Tinta tinta1, ConsoleColor color)
        {
            bool comparar = false;

            if(tinta1._color == color)
            {
                comparar = true;
            }

            return comparar;

        }

        public static bool operator !=(Tinta tinta1, ConsoleColor color)
        {
          

            return !(tinta1._color == color);

        }

        public static explicit operator string (Tinta MiTinta) //sobrecarga para castear
        {

            return MiTinta.Mostrar();
        }



    }
}

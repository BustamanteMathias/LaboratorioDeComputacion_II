﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Clase_06.Entidades
{
    public class Paleta
    {
        private Tempera[] colores;
        private int cantidadMaximaColores;

        private Paleta() : this(5)
        {

        }

        private Paleta(int cantidad)
        {
            this.colores = new Tempera[cantidadMaximaColores];
            this.cantidadMaximaColores = cantidad;
        }

        public static implicit operator Paleta(int cantidad)
        {


            return new Paleta(cantidad);

        }

        private string mostrar()
        {

            string mensaje = "Cantidad maxima de temperas: " + this.cantidadMaximaColores + "Cantidad de colores: ";

            for (int i = 0; i < cantidadMaximaColores; i++)
            {
                mensaje = mensaje + this.colores[i].ToString() + "\n";
            }

            return mensaje;



        }

        public static explicit operator string(Paleta miPaleta)
        {
            return miPaleta.mostrar();
        }

        public static bool operator ==(Paleta paleta, Tempera tempera1)
        {
            for (int i = 0; i < paleta.colores.Length; i++)
            {

                if (paleta.colores[i] == tempera1)
                {
                    return true;
                }

            }
            return false;

        }

        public static bool operator !=(Paleta paleta1, Tempera tempera1)
        {

            return !(paleta1 == tempera1);

        }

        private int ObtenerLugaLibre()
        {
            int retorno = -1;

            for (int i = 0; i < this.cantidadMaximaColores; i++)
            {

                if (object.Equals(this.colores[i], null))
                {
                    retorno = i;

                }
            }

                return retorno;

        }

        private int ObtenerTempera(Tempera tempera)
        {
            int retorno = -1;

            for (int i = 0; i < this.cantidadMaximaColores; i++)
            {

                if (this.colores[i] ==tempera)
                {
                    retorno = i;
                    break;

                }
            }

            return retorno;

        }
        public static Paleta operator +(Paleta paleta1, Tempera tempera1)
            {
               if(paleta1 == tempera1)
               {

                int indiceTempera;

                indiceTempera = paleta1.ObtenerTempera(tempera1);

                paleta1.colores[indiceTempera] += tempera1;



               }
            else
            {
                int indice;

                indice = paleta1.ObtenerLugaLibre();

                paleta1.colores[indice] = tempera1;
            }

            return paleta1;

            }

    }
}

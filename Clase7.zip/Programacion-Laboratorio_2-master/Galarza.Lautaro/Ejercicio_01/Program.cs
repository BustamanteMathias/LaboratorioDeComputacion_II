﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_01
{
    class Program
    {
        static void Main(string[] args)
        {
            int numero;
            int maximo = 0;
            int minimo = 0;
            int acumulador = 0;
            float promedio;
            int i;


            Console.Title = "Ejercicio 01";


            for (i = 0; i < 5; i++)
            {

                Console.WriteLine("Ingrese un numero:");

                numero = int.Parse(Console.ReadLine());

                if (i == 0)
                {

                    maximo = numero;
                    minimo = numero;

                }

                if (numero > maximo)
                {
                    maximo = numero;
                }

                else if (numero < minimo)
                {

                    minimo = numero;
                }

                acumulador = acumulador + numero;

            }

            promedio = (float)acumulador / i;

            Console.WriteLine("El valor maximo es   {0} ", maximo);
            Console.WriteLine("El valor minimo es  {0} ", minimo);
            Console.WriteLine("El promedio es  {0} ", promedio);


            Console.ReadLine();

        }
    }
}

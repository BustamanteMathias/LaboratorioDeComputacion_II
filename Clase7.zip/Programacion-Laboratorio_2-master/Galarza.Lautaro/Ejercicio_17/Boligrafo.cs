﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_Boligrafo
{
    class Boligrafo
    {
        public static short cantidadTintaMaxima = 100;


        ConsoleColor color;

        short tinta;

        public Boligrafo(short tinta, ConsoleColor color)
        {
            this.color = color;
            this.tinta = tinta;

        }

        public ConsoleColor GetColor()
        {
            return this.color;

        }

        public short GetTinta()
        {
            return this.tinta;
        }

        public bool Pintar(int gasto, out string dibujo)
        {
            bool PudoPintar = false;
            dibujo = "";

            if (this.GetTinta() > 0)
            {

                for (int i = 0; i < gasto; i++)
                {
                    dibujo = dibujo + "*";

                    this.SetTinta(-1);
                    if (this.GetTinta() <= 0)
                    {
                        break;
                    }

                }

                SetTinta((short)gasto);
                PudoPintar = true;

            }

            return PudoPintar;

        }

        public void Recargar()
        {
            this.SetTinta(Boligrafo.cantidadTintaMaxima);

        }

        void SetTinta(short tinta)
        {
            this.tinta += tinta;

            if (this.tinta < 0)
            {

                this.tinta = 0;
            }

            if (this.tinta > cantidadTintaMaxima)
            {
                this.tinta = cantidadTintaMaxima;

            }

        }







    }
}

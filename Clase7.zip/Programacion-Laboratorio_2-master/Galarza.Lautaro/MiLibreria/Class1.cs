﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MiLibreria
{
    public class MiClase
    {
        public static string nombre="pedrito";

        public static string MostrarNombre()
        {

            return MiClase.nombre;
        }

    }
}

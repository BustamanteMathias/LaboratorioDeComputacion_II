﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ClaseGenerica
{
    public class Deposito<T>
    {
        private int _capacidadMaxima;
        private List<T> _lista;

        public bool Agregar(T a)
        {
            return this + a;
        }
        public Deposito(int capacidad)
        {
            this._lista = new List<T>();
            this._capacidadMaxima = capacidad;
        }
        private int GetIndice(T a)
        {
            int aux = -1;

            foreach (T item in this._lista)
            {
                if (Equals(a))
                {
                    aux = this._lista.IndexOf(a);
                    break;
                }
            }

            return aux;
        }
        public bool Remover(T a)
        {
            return this - a;
        }
        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("\nCAPACIDAD: {0}\n", this._capacidadMaxima);

            foreach (T item in this._lista)
            {
                sb.AppendFormat("{0}", item.ToString());
            }
            sb.Append("\n");

            return sb.ToString();
        }
        public static bool operator -(Deposito<T> d, T a)
        {
            bool rtn = false;
            int aux = d.GetIndice(a);

            if (aux != -1)
            {
                d._lista.RemoveAt(aux); //ELIMINA POR INDICE
                rtn = true;
            }

            return rtn;
        }
        public static bool operator +(Deposito<T> d, T a)
        {
            bool rtn = false;

            if (d._lista.Count < d._capacidadMaxima)
            {
                d._lista.Add(a);
                rtn = true;
            }
            return rtn;
        }
    }
}

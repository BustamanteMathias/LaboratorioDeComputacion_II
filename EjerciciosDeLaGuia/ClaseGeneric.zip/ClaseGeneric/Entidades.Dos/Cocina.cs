﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Entidades.Dos
{
    public class Cocina
    {
        private int _codigo;
        private bool _esIndustrial;
        private double _precio;

        public int Codigo
        {
            get { return this._codigo; }
        }

        public bool EsIndustrial
        {
            get { return this._esIndustrial; }
        }

        public double Precio
        {
            get { return this._precio; }
        }
        public Cocina(int codigo, double precio, bool esIndustrial)
        {
            this._codigo = codigo;
            this._precio = precio;
            this._esIndustrial = esIndustrial;
        }

        public override bool Equals(object obj)
        {
            bool rtn = false;

            if(obj is Cocina)
            {
                if(this == (Cocina)obj)
                {
                    rtn = true;
                }
            }

            return rtn;
        }
        public static bool operator !=(Cocina a, Cocina b)
        {
            return !(a == b);
        }
        public static bool operator ==(Cocina a, Cocina b)
        {
            bool rtn = false;

            if(a.Codigo == b.Codigo)
            {
                rtn = true;
            }
            return rtn;
        }
        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("Codigo: {0}\tPrecio: {1}\t", this.Codigo, this.Precio);

            if (this._esIndustrial)
            {
                sb.Append("Es industrial\n");
            }
            else
            {
                sb.Append("No es industrial\n");
            }

            return sb.ToString();
        }
    }
}

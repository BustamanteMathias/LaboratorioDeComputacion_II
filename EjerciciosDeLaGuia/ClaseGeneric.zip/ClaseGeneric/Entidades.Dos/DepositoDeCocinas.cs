﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Entidades.Dos
{
    public class DepositoDeCocinas
    {
        private int _capacidadMaxima;
        private List<Cocina> _lista;

        public bool Agregar(Cocina a)
        {
            return this + a;
        }
        public DepositoDeCocinas(int capacidad)
        {
            this._lista = new List<Cocina>();
            this._capacidadMaxima = capacidad;
        }
        private int GetIndice(Cocina a)
        {
            int aux = -1;

            foreach (Cocina item in this._lista)
            {
                if (item == a)
                {
                    aux = this._lista.IndexOf(a);
                    break;
                }
            }

            return aux;
        }
        public bool Remover(Cocina a)
        {
            return this - a;
        }
        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("\nCAPACIDAD: {0}\n", this._capacidadMaxima);

            foreach (Cocina item in this._lista)
            {
                sb.AppendFormat("{0}", item.ToString());
            }
            sb.Append("\n");

            return sb.ToString();
        }
        public static bool operator -(DepositoDeCocinas d, Cocina a)
        {
            bool rtn = false;
            int aux = d.GetIndice(a);

            if (aux != -1)
            {
                d._lista.RemoveAt(aux); //ELIMINA POR INDICE
                rtn = true;
            }

            return rtn;
        }
        public static bool operator +(DepositoDeCocinas d, Cocina a)
        {
            bool rtn = false;

            if (d._lista.Count < d._capacidadMaxima)
            {
                d._lista.Add(a);
                rtn = true;
            }
            return rtn;
        }
    }
}

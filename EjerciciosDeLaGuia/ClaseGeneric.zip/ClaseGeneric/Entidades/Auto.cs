﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Entidades
{
    public class Auto
    {
        private string _color;
        private string _marca;

        public string Color
        {
            get { return this._color; }
        }
        public string Marca
        {
            get { return this._marca; }
        }
        public Auto(string color, string marca)
        {
            this._color = color;
            this._marca = marca;
        }

        public override bool Equals(object obj)
        {
            bool rtn = false;

            if(obj is Auto)
            {
                if((Auto)obj == this)
                {
                    rtn = true;
                }
            }
            return rtn;
        }

        public override string ToString()
        {
            return string.Format("Marca: {0}\tColor: {1}\n", this.Marca, this.Color);
        }

        public static bool operator !=(Auto a, Auto b)
        {
            return !(a == b);
        }
        public static bool operator ==(Auto a, Auto b)
        {
            bool rtn = false;

            if (a.Color == b.Color && a.Marca == b.Marca)
            {
                rtn = true;
            }
            return rtn;
        }
    }
}

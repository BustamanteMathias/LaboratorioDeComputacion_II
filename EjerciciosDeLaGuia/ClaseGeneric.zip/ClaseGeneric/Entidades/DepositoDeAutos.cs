﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Entidades
{
    public class DepositoDeAutos
    {
        private int _capacidadMaxima;
        private List<Auto> _lista;

        public bool Agregar(Auto a)
        {
            return this+a;
        }
        public DepositoDeAutos(int capacidad)
        {
            this._lista = new List<Auto>();
            this._capacidadMaxima = capacidad;
        }
        private int GetIndice(Auto a)
        {
            int aux = -1;

            foreach (Auto item in this._lista)
            {
                if (item == a)
                {
                    aux = this._lista.IndexOf(a);
                    break;
                }
            }

            return aux;
        }
        public bool Remover(Auto a)
        {
            return this-a;
        }
        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("\nCAPACIDAD: {0}\n", this._capacidadMaxima);

            foreach (Auto item in this._lista)
            {
                sb.AppendFormat("{0}", item.ToString());
            }
            sb.Append("\n");

            return sb.ToString();
        }
        public static bool operator -(DepositoDeAutos d, Auto a)
        {
            bool rtn = false;

            if (d.GetIndice(a) != -1)
            {
                d._lista.Remove(a);
                rtn = true;
            }

            return rtn;
        }
        public static bool operator +(DepositoDeAutos d, Auto a)
        {
            bool rtn = false;
            
            if (d._lista.Count < d._capacidadMaxima)
            {
                d._lista.Add(a);
                rtn = true;
            }
            return rtn;
        }
    }
}

using System;
using System.Collections.Generic;
using System.Text;

namespace Entidades_Clase14
{
    public class ErrorParserException: Exception
    {

    public ErrorParserException()
    {
      Console.Write("El string no podrá ser convertido. ");
    }

  }
}

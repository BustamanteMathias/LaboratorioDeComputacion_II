using Entidades_Clase14;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prueba.cs
{
  class Program
  {
    static void Main(string[] args)
    {
      int i = -99;
      Console.Write("NUMERO A VALIDAR: ");
      try
      {
        i = ParseadoraDeEnteros.Parse(Console.ReadLine());
      }
      catch (FormatException)
      {
        Console.Write("... Por error de formato.");
      }
      catch (OverflowException)
      {
        Console.Write("... Por tamaño del dato.");
      }
      finally
      {
        Console.WriteLine("I: " + i);
        Console.ReadKey();
      }
    }
  }
}

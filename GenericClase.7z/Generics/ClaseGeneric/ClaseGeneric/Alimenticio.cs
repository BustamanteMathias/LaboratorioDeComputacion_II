﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClaseGeneric
{
    public class Alimenticio : Producto
    {
        private DateTime vencimiento;

        public DateTime Vencimiento
        {
            get { return this.vencimiento; }
            set { this.vencimiento = value; }
        }

        public Alimenticio(int id, string descipcion, DateTime fechaVencimiento)
        {
            this.Vencimiento = fechaVencimiento;
            this.ID_prod = id;
            this.Descipcion = descipcion;
        }
    }
}

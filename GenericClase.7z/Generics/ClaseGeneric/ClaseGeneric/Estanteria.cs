﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClaseGeneric
{
    public class Estanteria <T> where T:Producto
    {
        private int tam;
        private T[] productos;

        public T[] Productos
        {
            get { return this.productos; }
            set { this.productos = value; }
        }

        public int Tam
        {
            get { return this.tam; }
            set { this.tam = value; }
        }
        
        public Estanteria(int tam)
        {
            this.Tam = tam;
            this.Productos = new T[tam];
        }

        /**
         * Estanteria <T,U,V,W...> where T: Producto (restrinjo)  
         * 
         * T[]
         * 
         */
        public static bool operator +(Estanteria<T> e, T p)
        {
            bool rtn = false;

            if (!Equals(e, null))
            {
                for (int i = 0; i < e.Productos.Length; i++)
                {
                    if (e.Productos[i] == null)
                    {
                        e.Productos[i] = p;
                        rtn = true;
                        break;
                    }
                }
            }

            return rtn;
        }

        public static bool operator -(Estanteria<T> e, T p)
        {
            bool rtn = false;

            if (!Equals(e, null) && e.Productos.Length != 0)
            {
                for (int i = 0; i < e.Productos.Length; i++)
                {
                    if (e.Productos[i].ID_prod == p.ID_prod)
                    {
                        e.Productos[i] = null;
                        rtn = true;
                        break;
                    }
                }
            }

            return rtn;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClaseGeneric
{
    public class Ferreteria : Producto
    {
        private float peso;

        public float Peso
        {
            get { return this.peso; }
            set { this.peso = value; }
        }

        public Ferreteria(int id, string descipcion, float peso)
        {
            this.Peso = peso;
            this.ID_prod = id;
            this.Descipcion = descipcion;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClaseGeneric
{
    public abstract class Producto
    {
        private int id_prod;
        private string descripcion;

        public string Descipcion
        {
            get { return this.descripcion; }
            set { this.descripcion = value; }
        }

        public int ID_prod
        {
            get { return this.id_prod; }
            set { this.id_prod = value; }
        }

    }
}

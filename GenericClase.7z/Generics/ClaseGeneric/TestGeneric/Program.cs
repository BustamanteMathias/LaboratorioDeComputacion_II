﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClaseGeneric;

namespace TestGeneric
{
    class Program
    {
        static void Main(string[] args)
        {
            Ferreteria f1 = new Ferreteria(1, "", 10);
            Ferreteria f2 = new Ferreteria(2, "", 10);
            Ferreteria f3 = new Ferreteria(3, "", 25);
            Ferreteria f4 = new Ferreteria(1, "", 10);
            Ferreteria f5 = new Ferreteria(2, "", 15);
            Ferreteria f6 = new Ferreteria(1, "", 7);

            Alimenticio a1 = new Alimenticio(3, "", new DateTime());
            Alimenticio a2 = new Alimenticio(1, "", new DateTime());
            Alimenticio a3 = new Alimenticio(1, "", new DateTime());
            Alimenticio a4 = new Alimenticio(2, "", new DateTime());
            Alimenticio a5 = new Alimenticio(3, "", new DateTime());
            Alimenticio a6 = new Alimenticio(1, "", new DateTime());

            Estanteria<Ferreteria> estanteriaFerreteria = new Estanteria<Ferreteria>(5);
            Estanteria<Alimenticio> estanteriaAlimenticio = new Estanteria<Alimenticio>(5);

            Console.WriteLine("\n Tamaño de estanteria Ferreteria: " + estanteriaFerreteria.Tam);

            #region CARGA PRODUCTOS A ESTANTERIA FERRETERIA

            if (estanteriaFerreteria + f1)
            {
                Console.WriteLine("Se agrego ferreteria a estanteria");
            }
            else
            {
                Console.WriteLine("No se pudo agregarferreteria a estanteria");
            }

            if (estanteriaFerreteria + f2)
            {
                Console.WriteLine("Se agrego ferreteria a estanteria");
            }
            else
            {
                Console.WriteLine("No se pudo agregarferreteria a estanteria");
            }

            if (estanteriaFerreteria + f3)
            {
                Console.WriteLine("Se agrego ferreteria a estanteria");
            }
            else
            {
                Console.WriteLine("No se pudo agregarferreteria a estanteria");
            }

            if (estanteriaFerreteria + f4)
            {
                Console.WriteLine("Se agrego ferreteria a estanteria");
            }
            else
            {
                Console.WriteLine("No se pudo agregarferreteria a estanteria");
            }

            if (estanteriaFerreteria + f5)
            {
                Console.WriteLine("Se agrego ferreteria a estanteria");
            }
            else
            {
                Console.WriteLine("No se pudo agregarferreteria a estanteria");
            }

            if (estanteriaFerreteria + f6)
            {
                Console.WriteLine("Se agrego ferreteria a estanteria");
            }
            else
            {
                Console.WriteLine("No se pudo agregarferreteria a estanteria");
            }
            #endregion

            Console.WriteLine("\n Tamaño de estanteria Alimenticia: " + estanteriaAlimenticio.Tam);

            #region CARGA PRODUCTOS A ESTANTERIA ALIMENTICIA

            if (estanteriaAlimenticio + a1)
            {
                Console.WriteLine("Se agrego producto a estanteria");
            }
            else
            {
                Console.WriteLine("No se pudo agregar el producto a la estanteria");
            }

            if (estanteriaAlimenticio + a2)
            {
                Console.WriteLine("Se agrego producto a estanteria");
            }
            else
            {
                Console.WriteLine("No se pudo agregar el producto a la estanteria");
            }

            if (estanteriaAlimenticio + a3)
            {
                Console.WriteLine("Se agrego producto a estanteria");
            }
            else
            {
                Console.WriteLine("No se pudo agregar el producto a la estanteria");
            }

            if (estanteriaAlimenticio + a4)
            {
                Console.WriteLine("Se agrego producto a estanteria");
            }
            else
            {
                Console.WriteLine("No se pudo agregar el producto a la estanteria");
            }

            if (estanteriaAlimenticio + a5)
            {
                Console.WriteLine("Se agrego producto a estanteria");
            }
            else
            {
                Console.WriteLine("No se pudo agregar el producto a la estanteria");
            }

            if (estanteriaAlimenticio + a6)
            {
                Console.WriteLine("Se agrego producto a estanteria");
            }
            else
            {
                Console.WriteLine("No se pudo agregar el producto a la estanteria");
            }
            #endregion

            Console.Read();
        }
    }
}

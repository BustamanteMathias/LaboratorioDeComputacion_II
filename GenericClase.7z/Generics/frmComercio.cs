using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ClaseGeneric;

namespace Generics
{
    public partial class frmComercio : Form
    {
    

    public frmComercio()
        {
            InitializeComponent();
        }

    private void frmComercio_Load(object sender, EventArgs e)
    {
      
    }

    private void btnCrear_Click(object sender, EventArgs e)
    {
      frmEstanteria estanteria = new frmEstanteria();
      estanteria.ShowDialog();

      this.cmbEstanteria.Items.Clear();
      foreach (Producto item in estanteria.estanterias)
      {
        this.cmbEstanteria.Items.Add("Estanteria ID: " + item.Descipcion);
      }
    }
  }
}

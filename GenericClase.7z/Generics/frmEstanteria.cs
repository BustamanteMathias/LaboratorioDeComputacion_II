using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ClaseGeneric;

namespace Generics
{
    public partial class frmEstanteria : Form
    {
    public List<object> estanterias = new List<object>();

    public frmEstanteria()
        {
            InitializeComponent();
        }

    private void frmEstanteria_Load(object sender, EventArgs e)
    {
      this.cmbParametro.Items.Add("Ferreteria");
      this.cmbParametro.Items.Add("Alimenticia");
      this.cmbParametro.Text = "Ferreteria";
    }

    private void button1_Click(object sender, EventArgs e)
    {
      int n;

      if (this.txtTamano.Text != string.Empty && int.TryParse(this.txtTamano.Text, out n))
      {
        if (n > 0)
        {
          if (this.cmbParametro.Text == "Ferreteria")
          {
            Estanteria<Ferreteria> f = new Estanteria<Ferreteria>(n);
            this.estanterias.Add(f);

            MessageBox.Show("Se cargo fereteria correctamente: Tamaño " + n);
          }
          else
          {
            Estanteria<Alimenticio> a = new Estanteria<Alimenticio>(n);
            this.estanterias.Add(a);

            MessageBox.Show("Se cargo alimenticia correctamente: Tamaño " + n);
          }
        }
        else
        {
          MessageBox.Show("No se admiten numeros negativos");
        }
      }
      else
      {
        MessageBox.Show("Caracteres invalidos");
      }
    }
  }
}

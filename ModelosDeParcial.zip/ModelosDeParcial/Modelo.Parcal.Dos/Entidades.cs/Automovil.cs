﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Entidades
{
    public class Automovil : Vehiculo
    {
        private ConsoleColor _color;
        private static int _valorHora;
        
        static Automovil()
        {
            Automovil._valorHora = 50;
        }
        public Automovil(string patente, ConsoleColor color) : base (patente)
        {
            this._color = color;
        }
        public Automovil (string patente, ConsoleColor color, int valorHora) : this(patente, color)
        {
            Automovil._valorHora = valorHora;
        }
        public override string ConsultarDatos()
        {
            return string.Format("{0}\nColor: {1}\n", base.ToString(), this._color.ToString());
        }
        public override bool Equals(object obj)
        {
            bool rtn = false;

            if (obj is Automovil)
            {
                rtn = true;
            }
            return rtn;
        }
        public override string ImprimirTicket()
        {
            DateTime actual = DateTime.Now;
            TimeSpan diferencia = actual.Subtract(this.ingreso);
            int costoTotal = diferencia.Hours * Automovil._valorHora;

            return string.Format("{0}\nEgreso: {1}\nCoste Total: {2}\n", base.ImprimirTicket(), actual.ToString(), costoTotal);
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Entidades
{
    public class Estacionamiento
    {
        private int _espacioDisponible;
        private string _nombre;
        private List<Vehiculo> vehiculos;

        private Estacionamiento()
        {
            vehiculos = new List<Vehiculo>();
        }
        public Estacionamiento(string nombre, int espacioDisponible) : this()
        {
            this._nombre = nombre;
            this._espacioDisponible = espacioDisponible;
        }

        public static explicit operator string(Estacionamiento e)
        {
            return string.Format("{0}\nEspacio Disponible: {1}\nEspacio Ocupado: {2}", e._nombre, e._espacioDisponible, e.vehiculos.Count);
        }
        public static bool operator ==(Estacionamiento e, Vehiculo v)
        {
            bool rtn = false;
            foreach (Vehiculo item in e.vehiculos)
            {
                if(item == v)
                {
                    rtn = true;
                    break;
                }
            }
            return rtn;
        }
        public static bool operator !=(Estacionamiento e, Vehiculo v)
        {
            return !(e == v);
        }
        public static string operator -(Estacionamiento e, Vehiculo v)
        {
            string rtn = "El vehículo no es parte del estacionamiento";

            foreach (Vehiculo item in e.vehiculos)
            {
                if (item == v)
                {
                    rtn = v.ImprimirTicket();
                    e.vehiculos.Remove(v);
                    break;
                }
            }
            return rtn;
        }
        public static Estacionamiento operator +(Estacionamiento e, Vehiculo v)
        {
            bool aux = false;
            
                foreach (Vehiculo item in e.vehiculos)
                {
                    if (item == v)
                    {
                        aux = true;
                        break;
                    }
                }
                if (aux == false && v.Patente != null && e._espacioDisponible > e.vehiculos.Count)
                {
                    e.vehiculos.Add(v);
                }
            return e;
        }
    }
}

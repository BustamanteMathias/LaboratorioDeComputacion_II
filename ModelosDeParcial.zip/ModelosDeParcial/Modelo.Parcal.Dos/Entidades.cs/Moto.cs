﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Entidades
{
    public class Moto : Vehiculo
    {
        private int _cilindrada;
        private short _ruedas;
        private static int _valorHora;

        static Moto()
        {
            Moto._valorHora = 30;
        }
        public Moto(string patente, int cilindrada) : base(patente)
        {
            this._ruedas = 2;
            this._cilindrada = cilindrada;
        }
        public Moto(string patente, int cilindrada, short ruedas) : this(patente, cilindrada)
        {
            this._ruedas = ruedas;
        }
        public Moto(string patente, int cilindrada, short ruedas, int valorHora) : this(patente, cilindrada, ruedas)
        {
            Moto._valorHora = valorHora;
        }
        public override string ConsultarDatos()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("{0}\nCilindrada: {1}\nRuedas: {2}\nValor Hora: {3}\n", base.ToString(), this._cilindrada, this._ruedas, Moto._valorHora);

            return sb.ToString();
        }
        public override bool Equals(object obj)
        {
            bool rtn = false;
            
            if(obj is Moto)
            {
                rtn = true;
            }
            return rtn;
        }
        public override string ImprimirTicket()
        {
            DateTime actual = DateTime.Now;
            TimeSpan diferencia = actual.Subtract(this.ingreso);
            int costoTotal = diferencia.Hours * Moto._valorHora;

            return string.Format("{0}\nEgreso: {1}\nCoste Total: {2}\n", base.ImprimirTicket(), actual.ToString(), costoTotal);
        }
    }
}

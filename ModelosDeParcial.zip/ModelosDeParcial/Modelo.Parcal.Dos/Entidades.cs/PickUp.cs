﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Entidades
{
    public class PickUp : Vehiculo
    {
        private string _modelo;
        private static int _valorHora;

        static PickUp()
        {
            PickUp._valorHora = 70;
        }
        public PickUp(string patente, string modelo) : base(patente)
        {
            this._modelo = modelo;
        }
        public PickUp(string patente, string modelo, int valorHora) : this(patente, modelo)
        {
            PickUp._valorHora = valorHora;
        }

        public override string ConsultarDatos()
        {
            return string.Format("{0}\nModelo: {1}\n", base.ToString(), this._modelo);
        }
        public override bool Equals(object obj)
        {
            bool rtn = false;

            if (obj is PickUp)
            {
                rtn = true;
            }
            return rtn;
        }
        public override string ImprimirTicket()
        {
            DateTime actual = DateTime.Now;
            TimeSpan diferencia = actual.Subtract(this.ingreso);
            int costoTotal = diferencia.Hours * PickUp._valorHora;

            return string.Format("{0}\nEgreso: {1}\nCoste Total: {2}\n", base.ImprimirTicket(), actual.ToString(), costoTotal);
        }
    }
}

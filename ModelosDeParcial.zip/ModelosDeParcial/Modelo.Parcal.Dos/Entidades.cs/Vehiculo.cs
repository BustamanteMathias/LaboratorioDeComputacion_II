﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Entidades
{
    public abstract class Vehiculo
    {
        public DateTime ingreso;
        private string _patente;

        public Vehiculo(string patente)
        {
            this.Patente = patente;
            this.ingreso = DateTime.Now.AddHours(-3);
        }
        public string Patente
        {
            get { return this._patente; }
            set
                {
                    if(value.Length == 6)
                    {
                        this._patente = value;
                    }
                }
        }

        public abstract string ConsultarDatos();

        public virtual string ImprimirTicket()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("{0}Ingreso: {1}", this.ToString(), this.ingreso.ToString());

            return sb.ToString();
        }
        public static bool operator ==(Vehiculo v1, Vehiculo v2)
        {
            bool rtn = false;

            if(v1.Equals(v2))
            {
                if (v1.Patente == v2.Patente)
                {
                    rtn = true;
                }
            }

            return rtn;
        }
        public static bool operator !=(Vehiculo v1, Vehiculo v2)
        {
            return !(v1==v2);
        }
        public override string ToString()
        {
            return string.Format("Patente {0}", this.Patente);
        }

    }
}

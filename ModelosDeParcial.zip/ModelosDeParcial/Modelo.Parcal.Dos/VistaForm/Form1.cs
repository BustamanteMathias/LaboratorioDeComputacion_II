﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Entidades;

namespace VistaForm
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.Text = "Crear PickUp";
            this.label1.Text = "Patente";
            this.label2.Text = "Modelo";
            this.button1.Text = "Crear";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            PickUp p = new PickUp(this.textBox1.Text, this.textBox2.Text);
            MessageBox.Show(p.ConsultarDatos());
            
        }
    }
}

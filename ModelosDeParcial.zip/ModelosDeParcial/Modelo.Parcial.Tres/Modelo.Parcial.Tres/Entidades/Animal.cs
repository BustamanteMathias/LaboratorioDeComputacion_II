﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public abstract class Animal
    {
        protected int _cantidadPatas;
        protected static Random _distanciaRecorrida;
        protected int _velocidadMaxima;

        public int CantidadPatas
        {
            get { return this._cantidadPatas; }
            set
            {
                if(value < 5 && value > -1)
                {
                    this._cantidadPatas = value;
                }
                else
                {
                    this._cantidadPatas = 4;
                }
            }
        }

        public int DistanciaRecorrida
        {
            get
            {
                Random rnd = new Random();
                int rtn = rnd.Next(10, this._velocidadMaxima+1);

                return rtn;
            }
        }

        public int VelocidadMaxima
        {
            get { return this._velocidadMaxima; }
            set
            {
                if (value < 61 && value > -1)
                {
                    this._velocidadMaxima = value;
                }
                else
                {
                    this._velocidadMaxima = 60;
                }
            }
        }

        static Animal()
        {
            Animal._distanciaRecorrida = new Random();
        }
        public Animal(int cantidadPatas, int velocidadMaxima)
        {
            this.CantidadPatas = cantidadPatas;
            this.VelocidadMaxima = velocidadMaxima;
        }
        public string MostrarDatos()
        {
            return string.Format("Cantidad de Patas: {0}\nDistancia Recorrida: {1}\nVelocidad Maxima{2}", this._cantidadPatas, Animal._distanciaRecorrida.ToString(), this.VelocidadMaxima);
        }
    }
}

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ModelosDeParcial.ParcialUno
{
    public abstract class Comensal
    {
        #region ATRIBUTOS

        private string _nombre;
        private string _apellido;
        #endregion

        #region PROPIEDADES

        public string Apellido
        {
            get { return this._apellido; }
        }
        public string Nombre
        {
            get { return this._nombre; }
        }
        #endregion

        public Comensal(string nombre, string apellido)
        {
            this._nombre = nombre;
            this._apellido = apellido;
            
        }

        public virtual string Mostrar()
        {
            return this.Apellido + " " + this.Nombre;
        }
    }
}

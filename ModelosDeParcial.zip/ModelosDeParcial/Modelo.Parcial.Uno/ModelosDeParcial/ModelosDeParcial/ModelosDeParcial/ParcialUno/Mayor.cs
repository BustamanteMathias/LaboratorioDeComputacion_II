using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ModelosDeParcial.ParcialUno
{
    public class Mayor : Comensal
    {
        private eBebidas _bebidas;

        private eBebidas bebida;

        public eBebidas Bebida
        {
            get { return bebida; }
        }

        public Mayor(string nombre, string apellido, eBebidas bebidas) : base (nombre, apellido)
        {
            this._bebidas = bebidas;
        }

        public static bool operator !=(Mayor a, Mayor b)
        {
            return !(a == b);
        }
        public static bool operator ==(Mayor a, Mayor b)
        {
            bool rtn = false;

            if (a.Nombre == b.Nombre && a.Apellido == b.Apellido)
            {
                rtn = true;
            }

            return rtn;
        }
        public override string ToString()
        {
            return string.Format("{0} Bebida: {1}\n", base.Mostrar(), this._bebidas.ToString());
        }

        public override bool Equals(object obj)
        {
            bool rtn = false;

            if (obj is Mayor)
            {
                if (this == (Mayor)obj)
                {
                    rtn = true;
                }
            }

            return rtn;
        }

        public static explicit operator string (Mayor a)
        {
            return a.ToString();
        }
    }
}

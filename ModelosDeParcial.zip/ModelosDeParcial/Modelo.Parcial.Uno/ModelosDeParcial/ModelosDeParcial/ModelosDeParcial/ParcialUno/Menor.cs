using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ModelosDeParcial.ParcialUno
{
    public class Menor : Comensal
    {
        private eMenu _menu;

        private eMenu menu;

        public eMenu Menu
        {
            get { return menu; }
            set { menu = value; }
        }

        private Menor(string nombre, string apellido) : base (nombre, apellido)
        {
        }
        public Menor(string nombre, string apellido, eMenu menu) : this (nombre , apellido)
        {
            this._menu = menu;
        }
        public static bool operator !=(Menor a, Menor b)
        {
            return !(a == b);
        }
        public static bool operator ==(Menor a, Menor b)
        {
            bool rtn = false;

            if (a.Nombre == b.Nombre && a.Apellido == b.Apellido)
            {
                rtn = true;
            }

            return rtn;
        }

        public override string Mostrar()
        {
            return string.Format("{0} Menu: {1} Menor\n", base.Mostrar(), this._menu.ToString());
        }
        public override string ToString()
        {
            return this.Mostrar();
        }

        public override bool Equals(object obj)
        {
            bool rtn = false;

            if( obj is Menor)
            {
                if(this == (Menor)obj)
                {
                    rtn = true;
                }
            }

            return rtn;
        }
    }
}

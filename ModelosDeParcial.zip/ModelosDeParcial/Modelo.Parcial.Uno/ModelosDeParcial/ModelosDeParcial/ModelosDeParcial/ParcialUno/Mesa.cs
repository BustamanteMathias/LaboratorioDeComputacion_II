using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ModelosDeParcial.ParcialUno
{
    public class Mesa
    {
        private List<Comensal> _comensal;
        private int _numero;
        public static int capacidad;

        #region PROPIEDADES
        public int Cantidad
        {
            get
            {
                return this._comensal.Count;
            }
        }

        public List<Comensal> Comensales
        {
            get { return this._comensal; }
        }
        
        public int Numero
        {
            get { return this._numero; }

            set { this._numero = value; }
        }
        #endregion

        static Mesa()
        {
            Mesa.capacidad = 12;
        }

        private Mesa()
        {
            this._comensal = new List<Comensal>();
        }

        public Mesa(int numero) : this()
        {
            this.Numero = numero;
        }

        public static bool operator !=(Mesa a, Mesa b)
        {
            return !(a == b);
        }
        public static bool operator ==(Mesa a, Mesa b)
        {
            bool rtn = false;

            if(a.Numero == b.Numero)
            {
                rtn = true;
            }
            return rtn;
        }
        public static Mesa operator +(Mesa a, Mayor b)
        {
            bool aux = false;

            if(a.Comensales != null)
            {
                foreach (Mayor item in a.Comensales)
                {
                    if (b == item)
                    {
                        aux = true;
                        break;
                    }
                }
            }

            if(aux == false && a.Cantidad < Mesa.capacidad)
            {
                a.Comensales.Add(b);
            }
            return a;
        }
        public static Mesa operator +(Mesa a, Menor b)
        {
            bool aux = false;

            foreach (Menor item in a.Comensales)
            {
                if(item is Menor)
                {
                    if (b == item)
                    {
                        aux = true;
                        break;
                    }
                }
            }
            if (aux == false && a.Cantidad < Mesa.capacidad)
            {
                a.Comensales.Add(b);
            }
            return a;
        }

        public override string ToString()
        {
            return string.Format("Mesa: {0} Comensales: {1}\n", this.Numero, this.Cantidad);
        }

        public static implicit operator string (Mesa a)
        {
            string rtn = "";
            rtn = a.ToString();

            foreach (Comensal item in a.Comensales)
            {
                rtn = rtn + item.ToString() + "\n";
            }
            return rtn;
        }
    }
}

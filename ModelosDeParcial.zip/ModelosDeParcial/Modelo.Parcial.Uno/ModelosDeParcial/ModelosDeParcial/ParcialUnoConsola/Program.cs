using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ModelosDeParcial.ParcialUno;

namespace ParcialUnoConsola
{
    class Program
    {
        static void Main(string[] args)
        {
            Mesa mesa = new Mesa(1);
            Mayor mayor1 = new Mayor("mathias", "bustamante", eBebidas.Cerveza);
            Mayor mayor2 = new Mayor("belen", "damiano", eBebidas.Vino);
            mesa = mesa + mayor1 + mayor2;
            Console.WriteLine(mesa);
            Console.ReadKey();
        }
    }
}

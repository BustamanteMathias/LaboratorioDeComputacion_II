using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ComiqueriaLogic
{
  public class Comiqueria
  {
    private List<Producto> productos;
    private List<Venta> ventas;

    public Producto this[Guid codigo]
    {
      get
      {
        Producto rtn = null;

        if (this.productos != null)
        {
          foreach (Producto item in this.productos)
          {
            if(codigo == (Guid)item)
            {
              rtn = item;
              break;
            }
          }
        }
        return rtn;
      }
    }

    public Comiqueria()
    {
      this.productos = new List<Producto>();
      this.ventas = new List<Venta>();
    }

    public Dictionary<Guid, string> ListarProductos()
    {
      Dictionary<Guid, string> lista = new Dictionary<Guid, string>();

      foreach (Producto item in this.productos)
      {
        lista.Add((Guid)item, item.Descripcion);
      }
      return lista;
    }

   

    public string ListarVentas()
    {
      StringBuilder s = new StringBuilder();
      
      this.ventas.Sort(Venta.OrdenarPorFecha);

      foreach (Venta item in this.ventas)
      {
        s.AppendLine(item.ObtenerDescripcionBreve());
      }

      return s.ToString();
    }
    public void Vender(Producto producto)
    {
      this.Vender(producto, 1);
    }
    public void Vender(Producto producto, int cantidad)
    {
      this.ventas.Add(new Venta(producto, cantidad));
    }
    public static bool operator != (Comiqueria comiqueria, Producto producto)
    {
      return !(comiqueria == producto);
    }
    public static bool operator ==(Comiqueria comiqueria, Producto producto)
    {
      bool rtn = false;

      foreach (Producto item in comiqueria.productos)
      {
        if(item.Descripcion == producto.Descripcion)
        {
          rtn = true;
          break;
        }
      }

      return rtn;
    }
    public static Comiqueria operator +(Comiqueria comiqueria, Producto producto)
    {
      bool flag = false;

      foreach (Producto item in comiqueria.productos)
      {
        if (item == producto)
        {
          flag = true;
          break;
        }
      }

      if (!flag)
      {
        comiqueria.productos.Add(producto);
      }

      return comiqueria;
    }
  }
}

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ComiqueriaLogic
{
  public abstract class Producto
  {
    private Guid codigo;
    private string descripcion;
    private double precio;
    private int stock;

    public string Descripcion { get { return this.descripcion; } }
    public double Precio { get { return this.precio; } }
    public int Stock { get { return this.stock; } set { this.stock = value; } }

    protected Producto(string descripcion, int stock, double precio)
    {
      this.codigo = Guid.NewGuid();
      this.descripcion = descripcion;
      this.stock = stock;
      this.precio = precio;
    }
    public override string ToString()
    {
      StringBuilder s = new StringBuilder();
      s.AppendFormat("Descripción: Figura {0} cm\n", this.Descripcion);
      s.AppendFormat("Código: {0}\n", this.codigo.ToString());
      s.AppendFormat("Precio: ${0:0.00}\n", this.Precio);
      s.AppendFormat("Stock: {0} unidades", this.Stock.ToString());
      return s.ToString();
    }
    public static explicit operator Guid(Producto p)
      {
      return p.codigo;
      }
  }
}

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ComiqueriaLogic
{
  public sealed class Venta
  {
    private DateTime fecha;
    private static int porcentajeIva;
    private double precioFinal;
    private Producto producto;

    public DateTime Fecha { get { return this.fecha.Date; } }

    static Venta()
    {
      Venta.porcentajeIva = 21;
    }
    internal Venta(Producto producto, int cantidad)
    {
      this.producto = producto;
      this.Vender(cantidad);
    }
    private void Vender(int cantidad)
    {
      this.producto.Stock = this.producto.Stock - cantidad;
      this.fecha = DateTime.Now;
      this.precioFinal = Venta.CalcularPrecioFinal(this.producto.Precio, cantidad);
    }

    public string ObtenerDescripcionBreve()
    {
      return string.Format("{0} - {1} - {2:0.00}", this.Fecha.ToString(), this.producto.Descripcion, this.precioFinal);
    }

    public static double CalcularPrecioFinal(double precioUnidad, int cantidad)
    {
      double total = precioUnidad * cantidad;
      double totalConIva = total + (total * (Venta.porcentajeIva / 100f));

      return totalConIva;
    }

    public static int OrdenarPorFecha(Venta v1, Venta v2)
    {
      return DateTime.Compare(v1.Fecha, v2.Fecha);
    }
  }
}

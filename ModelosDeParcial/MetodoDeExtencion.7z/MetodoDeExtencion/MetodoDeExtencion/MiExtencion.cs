using System;
using System.Collections.Generic;
using System.Text;

namespace MetodoDeExtencion
{
    public static class MiExtencion
    {
    public static void PruebaExtencion(this long numero)
    {
      string rtn = Convert.ToString(numero);
      Console.WriteLine("La cantidad de digitos es: " + rtn.Length);
    }

    public static void PruebaExtencionCantidadPuntuacion(this string cadena)
    {
      int contador = 0;

      int countComas = 0;
      int countPunto = 0;
      int countPuntoComa = 0;

      foreach (char item in cadena)
      {
        if (item is '.' || item is ',' || item is ';')
        {
          contador++;

          switch (item)
          {
            case ',':
              countComas++;
              break;
            case '.':
              countPunto++;
              break;
            case ';':
              countPuntoComa++;
              break;
          }
        }
      }
      Console.WriteLine("CANTIDAD DE SIGNOS DE PUNTUACION: " + contador);
      Console.WriteLine("Cantidad Punto = " + countPunto);
      Console.WriteLine("Cantidad Comas = " + countComas);
      Console.WriteLine("Cantidad Punto y coma = " + countPuntoComa);

    }
  }
}

using System;

namespace MetodoDeExtencion
{
    class Test
    {
        static void Main(string[] args)
        {
      long numero;
      string aux = string.Empty;

      Console.WriteLine("Digite un numero para saber la cantidad de digitos: ");
      aux = Console.ReadLine();
      numero = long.Parse(aux);

      numero.PruebaExtencion();

      Console.WriteLine("Digite una cadena para saber la cantidad de signos de puntuacion: ");
      aux = string.Empty;
      aux = aux = Console.ReadLine();

      aux.PruebaExtencionCantidadPuntuacion();
      Console.ReadKey();


        }
    }
}

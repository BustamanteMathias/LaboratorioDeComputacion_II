using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ENTIDADES.RPP
{
  public class BancoMunicipal : Banco
  {
    public BancoProvincial bp;
    public string municipio;

    public BancoMunicipal(BancoProvincial bp, string municipio) : base(bp.nombre)
    {
      this.bp = bp;
      this.municipio = municipio;
    }

    public override string Mostrar()
    {
      return base.nombre;
    }

    public override string Mostrar(Banco b)
    {
      return string.Format("Nombre: {0}\nProvincia: {1}\nMunicipio: {2}", b.Mostrar(), this.bp.provincia, this.municipio);
    }
  }
}

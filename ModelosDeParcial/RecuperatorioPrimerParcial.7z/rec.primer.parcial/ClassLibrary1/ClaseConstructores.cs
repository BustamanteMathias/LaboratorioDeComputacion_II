using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ENTIDADES.RPP
{
  public class ClaseConstructores
  {
    private string lectura;

    public string Lectura
    {
      get { return this.lectura; }
    }

    public string Escritura
    {
      set
      {
        MessageBox.Show("Propiedad de solo Escritura");
        this.lectura = value;
      }
    }

    static ClaseConstructores()
    {
      MessageBox.Show("Constructor Estatico");
    }
    private ClaseConstructores(int a, int b)
    {
      MessageBox.Show("Constructor Privado");
    }
    public ClaseConstructores() : this (1, 2)
    {
      MessageBox.Show("Constructor Publico");

      this.Escritura = "Propiedad de solo Lectura";

      MessageBox.Show(this.Lectura);

      this.MetodoInstancia();
    }
    void MetodoInstancia()
    {
      MessageBox.Show("Metodo de Instancia");
      ClaseConstructores.MetodoClase();
    }

    public static void MetodoClase()
    {
      MessageBox.Show("Metodo de Clase");
    }
  }
}

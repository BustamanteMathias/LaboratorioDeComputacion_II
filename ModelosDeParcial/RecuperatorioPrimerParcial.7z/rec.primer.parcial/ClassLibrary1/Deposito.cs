using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ENTIDADES.RPP
{
  public class Deposito
  {
    public List<Producto> productos;

    public Deposito()
    {
      productos = new List<Producto>(3);
    }

    public Deposito(int cantidadStock) : this()
    {
      this.productos.Capacity = cantidadStock;
    }

    public static List<Producto> operator +(Deposito d1, Deposito d2)
    {
      List<Producto> aux = d1.productos;

      foreach (Producto item in d2.productos)
      {
        if (aux.Contains(item))
        {
          for (int i = 0; i < aux.Count; i++)
          {
            if(aux[i].nombre == item.nombre)
            {
              aux[i].stock = aux[i].stock + item.stock;
            }
          }
        }
        else
        {
          aux.Add(item);
        }
      }

      return aux;
    }

}
}

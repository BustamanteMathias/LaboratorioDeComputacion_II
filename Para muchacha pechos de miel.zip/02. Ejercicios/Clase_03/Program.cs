﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Libreria;

namespace Clase_03
{
    class Clase_03
    {
        static void Main(string[] args)
        {
            // USO DE OBJETO CARGADO POR REFERENCIA .dll DESDE EL USO DE using Libreria

            Libreria.Test.Saludar();
            Console.ReadKey();
        }
    }
}

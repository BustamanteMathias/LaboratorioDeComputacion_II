using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Clase_04.Entidades
{
  public class Cosa

  {
    public int entero;
    public string cadena;
    public DateTime fecha;

    //METODOS
    public string Mostrar()
    {
      string retorno = this.entero.ToString() + " - " + this.cadena + " - " + this.fecha.ToString();

      return retorno;
    }

    public static string Mostrar(Cosa objeto)
    {
      string retorno = objeto.Mostrar();

      return retorno;
    }

    public void EstablecerValor(int valorInt)
    {
      this.entero = valorInt;
    }

    public void EstablecerValor(string valorCadena)
    {
      this.cadena = valorCadena;
    }
    public void EstablecerValor(DateTime valorFecha)
    {
      this.fecha = valorFecha;
    }

    //CONSTRUCTORES

    public Cosa()
    {
      this.cadena = "SIN VALOR";
      this.entero = 10;
      this.fecha = DateTime.Now;
    }

    public Cosa(int valorInt) : this()
    {
      this.entero = valorInt;

      //this.cadena = "SIN VALOR";
      //this.fecha = DateTime.Now;
    }

    public Cosa(int valorInt, DateTime fecha) : this (valorInt)
    {
      //this.entero = valorInt;
      this.fecha = fecha;
      //this.cadena = "SIN VALOR";
    }

    public Cosa(int valorInt, DateTime fecha, string valorCadena) : this (valorInt, fecha)
    {
      //this.entero = valorInt;
      //this.fecha = fecha;
      this.cadena = valorCadena;
    }

    //public Cosa(string valorString)
    //{
    //  this.cadena = valorString;

    //  this.entero = 10;
    //  this.fecha = DateTime.Now;
    //}

    //public Cosa(DateTime fecha)
    //{
    //  this.cadena = "SIN VALOR";
    //  this.entero = 10;
    //  this.fecha = fecha;
    //}
  }
}


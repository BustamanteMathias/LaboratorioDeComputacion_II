using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Clase_04.Entidades
{
  class Clase_04
  {
    static void Main(string[] args)
    {

      Cosa miCosa = new Cosa();

      //Sobrecarga de Metodo I
      Console.WriteLine(miCosa.Mostrar());
      //Sobrecarga de Metodo II
      //Console.WriteLine(miCosa.Mostrar(miCosa));

      Console.ReadKey();
    }
  }
}

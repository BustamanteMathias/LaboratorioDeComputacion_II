using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Clase_04.Entidades;

namespace Clase_04.Test
{
  class Clase_04
  {
    static void Main(string[] args)
    {
      Cosa miCosaDefault = new Cosa();
      Console.WriteLine(miCosaDefault.Mostrar());
      Console.ReadKey();

      Cosa miCosaUno = new Cosa(9999);
      Console.WriteLine(miCosaUno.Mostrar());
      Console.ReadKey();

      //  Cosa miCosaDos = new Cosa("HOLA");
      //  Console.WriteLine(miCosaDos.Mostrar());
      //  Console.ReadKey();

      //  Cosa miCosaTres = new Cosa(DateTime.Now);
      //  Console.WriteLine(miCosaTres.Mostrar());
      //  Console.ReadKey();
      //
    }
  }
}

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Clase_04.Entidades;

namespace Clase_04.WindowsForms
{
    public partial class frmCosa : Form
    {
        public frmCosa()
        {
            InitializeComponent(); //CONSTRUCTOR

        }

        private void frmCosa_Load(object sender, EventArgs e)
        {
            //MessageBox.Show("Hola Mundo");
            this.Text = "Mi primer programa weon";
            this.BackColor = Color.Cyan;
            this.MaximizeBox = false; //MAXIMIZAR VENTANA

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Cosa miCosa = new Cosa(); //AL HACER CLICK SE EJECUTA ESTE EVENTO, DONDE CREA OBJETO miCosa Y LO IMPRIME EN VENTANA
            MessageBox.Show(Cosa.Mostrar(miCosa));
            this.button1.Text = "Crear una cosa bonita (?"; // SET EN TIEMPO DE EJECUCION


        }
    }
}

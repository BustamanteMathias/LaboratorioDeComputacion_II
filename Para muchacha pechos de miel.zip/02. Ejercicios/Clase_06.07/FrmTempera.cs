using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Clase_06;

namespace Clase_06._07
{
  public partial class FrmTempera : Form
  {
        private Tempera _tempera;

        public Tempera miTempera
        {
            get { return _tempera; }
        }

        public FrmTempera()
    {
      InitializeComponent();
      label1.Text = "Marca";
      label2.Text = "Color";
      label3.Text = "Cantidad";

      button1.Text = "Aceptar";
      button2.Text = "Cancelar";


         foreach (ConsoleColor item in Enum.GetValues(typeof(ConsoleColor)))
         {
           comboBox1.Items.Add(item);
         } //Enum.GetValues(typeof (ConsoleColor))
           this.comboBox1.DropDownStyle = ComboBoxStyle.DropDownList; //Para que solo sean seleccionables los item del enum
     }

    private void button1_Click(object sender, EventArgs e)
    {
     Tempera miTempera = new Tempera((ConsoleColor)this.comboBox1.SelectedItem, this.textBox1.Text, sbyte.Parse(this.textBox2.Text));
            MessageBox.Show(Tempera.Mostrar(miTempera));
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}

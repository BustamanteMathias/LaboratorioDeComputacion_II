﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Clase_06._07
{
    public partial class frmPrincipal : Form
    {
        public frmPrincipal()
        {
            InitializeComponent();
            this.IsMdiContainer = true; //Para que el formulario principal pueda contener otros formularios
            this.WindowState = FormWindowState.Maximized; //Para maximizar
        }

        private void frmPrincipal_Load(object sender, EventArgs e)
        {
            
        }

        private void agregarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmPaleta frmP = new FrmPaleta();
            frmP.MdiParent = this; //Para decirle quien es el padre y se contenga dentro del formulario (this =menuprincipal)
            frmP.StartPosition = FormStartPosition.CenterScreen;
            frmP.Show();
        }

        private void salirToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //this.frmPrincipal_FormClosing(sender, new FormClosingEventArgs(CloseReason.UserClosing, true));
        }

        private void frmPrincipal_FormClosing(object sender, FormClosingEventArgs e)
        {
            //if (MessageBox.Show("Seguro que desea sair", "Alerta", MessageBoxButtons.OKCancel, MessageBoxIcon.Exclamation) == DialogResult.Cancel)
            //{
            //    e.Cancel = true;
            //}
        }
    }
}

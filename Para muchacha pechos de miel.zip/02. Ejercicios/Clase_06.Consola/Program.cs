using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Clase_06.Tempera
{
  class Program
  {
    static void Main(string[] args)
    {
      Paleta p = 3;

      Console.WriteLine((string)p);
      Console.Read();
    }
  }
}

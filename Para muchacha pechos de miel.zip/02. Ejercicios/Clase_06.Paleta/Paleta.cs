using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Clase_06
{ 
    public class Paleta
    {
    private Tempera[] _temperas;
    private int _cantidadMaxima;

    private Paleta() //eran privadas
    {
    }

    private Paleta(int cMax)
    {
      this._temperas = new Tempera[cMax];
      this._cantidadMaxima = cMax;
    }

    public static implicit operator Paleta (int cMax)
    {
      Paleta p = new Paleta(cMax);

      return p;
    }

    private string Mostrar ()
    {

      string s = "Tempera: " + this._temperas.ToString() + "\nCantidad Maxima: " + this._cantidadMaxima.ToString();
      return s;
    }

    public static explicit operator string (Paleta p)
    {
      string s = "";

      foreach (Tempera item in p._temperas)
      {
        s = s + p.Mostrar();
      }

      return s;
    }

    // (+) == (paleta, tempera): bool

    public static bool operator ==(Paleta p, Tempera t)
    {
      bool r = false;

      foreach (Tempera item in p._temperas)
      {
        if (item == t)
        {
          r = true;
        }
      }

      return r;
    }

    public static bool operator !=(Paleta p, Tempera t)
    {
      return !(p == t);
    }
    // (+) + (paleta, tempera): paleta

    public static Paleta operator +(Paleta p, Tempera t)
    {

      if (p == t)
      {
        Paleta auxPal = p;
      }
      return p;
    }

    private int ObtenerIndice()
    {
      int r = -1;

      foreach (Tempera item in this._temperas)
      {
        if (item != null)
        {
          r = item;
        }
      }
      return r;
    }

    // this,_temperas{indice} = t
  } 
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Vehiculos;

namespace Clase_09.TestHerenciaVehiculo
{
    class Tests
    {
        static void Main(string[] args)
        {
            //Auto miAuto = new Auto();
            //Moto miMoto = new Moto();
            //Camion miCamion = new Camion();

            Console.ReadKey();
        }
    }
}

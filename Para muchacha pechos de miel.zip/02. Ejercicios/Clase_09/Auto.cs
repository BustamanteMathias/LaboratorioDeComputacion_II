﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Vehiculos
{
    public class Auto : Vehiculo
    {
        protected int _cantAsientos;

        public Auto (string s, byte b, EMarca m, int a) : base(s, b, m)
        {
            this._cantAsientos = a;
        }

        public string MostrarAuto()
        {
           return base.Mostrar() + " Asientos: " + this._cantAsientos.ToString();
        }
    }
}

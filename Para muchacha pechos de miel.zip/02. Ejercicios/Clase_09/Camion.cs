﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Vehiculos
{
    public class Camion : Vehiculo
    {
        protected float _tara;

        public Camion(string s, byte b, EMarca m, float t) : base(s,b,m)
        {
            this._tara = t;
        }

        public string MostrarCamion()
        {
            return base.Mostrar() + " Tara: " + _tara.ToString();
        }
    }
}

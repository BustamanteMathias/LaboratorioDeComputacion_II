﻿public enum EMarca
{
    Honda, Ford, Zanella, Scania, Iveco, Fiat
}
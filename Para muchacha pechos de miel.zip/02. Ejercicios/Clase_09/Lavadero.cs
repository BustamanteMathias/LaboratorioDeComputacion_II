﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Vehiculos;

namespace Clase_09
{
    public class Lavadero
    {
        private List<Vehiculo> _vehiculos;
        private float _precioAuto;
        private float _precioMoto;
        private float _precioCamion;
        private string MiLavadero;
        private string MisVehiculos;

        public string miVehiculo
        {
            get { return MisVehiculos; }
        }

        public string miLavadero
        {
            get { return MiLavadero; }
        }

        private Lavadero()
        {
            _vehiculos = new List<Vehiculo>();

            this.MisVehiculos = "Autos\n\n";
            foreach (Auto item in this._vehiculos)
            {
                MisVehiculos += item.MostrarAuto() + "\n";
            }

            this.MisVehiculos = "Motos\n\n";
            foreach (Moto item in this._vehiculos)
            {
                MisVehiculos += item.MostrarMoto() + "\n";
            }

            this.MisVehiculos = "Camiones\n\n";
            foreach (Camion item in this._vehiculos)
            {
                MisVehiculos += item.MostrarCamion() + "\n";
            }
        }

        public Lavadero (float precioAuto, float precioCamion, float precioMoto) : this()
        {
            this._precioAuto = precioAuto;
            this._precioCamion = precioCamion;
            this._precioMoto = precioMoto;

            this.MiLavadero =   "Precio Auto: " + this._precioAuto +
                                "Precio Camion: " + this._precioCamion +
                                "Precio Moto: " + this._precioMoto;

            foreach (Auto item in this._vehiculos)
            {
                MiLavadero += item.MostrarAuto() + "\n";
            }

            foreach (Moto item in this._vehiculos)
            {
                MiLavadero += item.MostrarMoto() + "\n";
            }

            foreach (Camion item in this._vehiculos)
            {
                MiLavadero += item.MostrarCamion() + "\n";
            }

        }

        

    }
}

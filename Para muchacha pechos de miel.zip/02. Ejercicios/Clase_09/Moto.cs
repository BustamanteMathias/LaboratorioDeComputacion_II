﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Vehiculos
{
    public class Moto : Vehiculo
    {
        protected float _cilindrada;

        public Moto(string s, byte b, EMarca m, float c) : base (s, b, m)
        {
            this._cilindrada = c;
        }

        public string MostrarMoto()
        {
            return base.Mostrar() + " Cilindradas: " + this._cilindrada.ToString();
        }
    }
}

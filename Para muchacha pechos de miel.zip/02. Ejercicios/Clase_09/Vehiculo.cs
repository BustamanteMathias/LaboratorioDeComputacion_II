﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Vehiculos
{
    public class Vehiculo
    {

        #region Atributos
        protected string _patente;
        protected byte _cantRuedas;
        protected EMarca _marca;

        protected EMarca marca
        {
            get { return this._marca; }
        }

        protected string patente
        {
            get { return this._patente; }
        }
        #endregion

        #region Constructor
        public Vehiculo(string s, byte b, EMarca e)
        {
            this._patente = s;
            this._cantRuedas = b;
            this._marca = e;
        } 
        #endregion

        #region Metodos

        protected string Mostrar()
        {
            return this._patente + " - " + this._marca.ToString() + " - " + "CRuedas: " + this._cantRuedas.ToString();
        } 
        #endregion

        public static bool operator ==(Vehiculo v1, Vehiculo v2)
        {
            bool rtn = false;

            if (v1._patente == v2.patente)
            {
                rtn = true;
            }

            return rtn;
        }

        public static bool operator !=(Vehiculo v1, Vehiculo v2)
        {
            return !(v1 == v2);
        }
    }
}

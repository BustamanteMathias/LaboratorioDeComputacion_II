﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EjercicioNro_16
{
    public class Alumno
    {
        private byte nota1;
        private byte nota2;
        private float notaFinal;

        public string apellido;
        public string nombre;
        public int legajo;


        public void CalcularFinal()
        {
            if (this.nota2 >= 4  && this.nota1 >= 4)
            {
                Random miRandom = new Random();

                this.notaFinal = miRandom.Next();
            }
            else
            {
                this.notaFinal = -1;
            }

        }

        public void Estudiar(byte notaUno, byte notaDos)
        {
            this.nota1 = notaUno;
            this.nota2 = notaDos;

            this.CalcularFinal();
        }

        public string Mostrar()
        {
            string retornoCadena = "";

            if (this.notaFinal != -1)
            {
                retornoCadena = ("Legajo: " + this.legajo +
                    "\nApellido: " + this.apellido +
                    "\nNombre: " + this.nombre +
                    "\nNota 1: " + this.nota1 +
                    "\nNota 2: " + this.nota2 +
                    "\nNota Final: " + this.notaFinal + "\n\n");
            }
            else
            {
                retornoCadena = ("Legajo: " + this.legajo +
                    "\nApellido: " + this.apellido +
                    "\nNombre: " + this.nombre +
                    "\nNota 1: " + this.nota1 +
                    "\nNota 2: " + this.nota2 + "\n\n");
            }

            return retornoCadena;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EjercicioNro_16
{
    class EjercicioNro_16
    {
        static void Main(string[] args)
        {
            /*
             * a. Se pide crear 3 instancias de la clase Alumno (3 objetos) en la función Main. 
                  Colocarle nombre, apellido y legajo a cada uno de ellos.
               b. Sólo se podrá ingresar las notas (nota1 y nota2) a través del método Estudiar.
               c. El método CalcularFinal deberá colocar la nota del final sólo si las notas 1 y 2 son mayores 
                  o iguales a 4, caso contrario la inicializará con -1. 
                  Para darle un valor a la nota final utilice el método de instancia Next de la clase Random.
               d. El método Mostrar, expondrá en la consola todos los datos de los alumnos. 
                  La nota final se mostrará sólo si es distinto de -1, 
                  caso contrario se mostrará la leyenda "Alumno desaprobado".
             */

            Console.Title = "EjercicioNro_16";

            Alumno alumnoUno = new Alumno();
            Alumno alumnoDos = new Alumno();
            Alumno alumnoTres = new Alumno();

            //ALUMNO 1
            alumnoUno.nombre = "Carlos";
            alumnoUno.apellido = "Cacatua";
            alumnoUno.legajo = 8000;
            alumnoUno.Estudiar(5, 5);
            Console.WriteLine(alumnoUno.Mostrar());

            //ALUMNO 2
            alumnoDos.nombre = "Juan";
            alumnoDos.apellido = "Huevon";
            alumnoDos.legajo = 69;
            alumnoDos.Estudiar(3, 5);
            Console.WriteLine(alumnoDos.Mostrar());

            //ALUMNO 3
            alumnoTres.nombre = "Elver";
            alumnoTres.apellido = "Galarga";
            alumnoTres.legajo = 4;
            alumnoTres.Estudiar(10, 10);
            Console.WriteLine(alumnoTres.Mostrar());

            Console.WriteLine("FALTA ARREGLAR LOS DECIMALES DE LA NOTA FINAL PARA SOLO MOSTRAR DOS");
            Console.ReadKey();

        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EjercicioNro_19
{
    class EjercicioNro_19
    {
        static void Main(string[] args)
        {
            Sumador miSumador = new Sumador(15);
            Sumador miSumadorDos = new Sumador(10);

            Console.WriteLine(miSumador | miSumadorDos);
            Console.ReadKey();
        }
    }
}

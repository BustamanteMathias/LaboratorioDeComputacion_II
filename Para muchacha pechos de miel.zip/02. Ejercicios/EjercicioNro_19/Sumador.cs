﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EjercicioNro_19
{
    public class Sumador
    {
        private int cantidadSumas;

        public Sumador(int var)
        {
            this.cantidadSumas = var;
        }

        public Sumador()
        {
            Sumador miSumador = new Sumador(0);
            this.cantidadSumas = miSumador.cantidadSumas;
        }

        public long Sumar(long a, long b)
        {
            long res;
            this.cantidadSumas++;

            res = a + b;

            return res;
        }

        public string Sumar(string a, string b)
        {
            string res = "";
            this.cantidadSumas++;

            res = res + a + b;

            return res;
        }

        public int CantidadSumas()
        {
            return this.cantidadSumas;
        }

        public static long operator +(Sumador sumadorUno, Sumador sumadorDos)
        {
            long res;
            res = sumadorUno.cantidadSumas + sumadorDos.cantidadSumas;

            return res;
        }

        public static bool operator |(Sumador sumadorUno, Sumador sumadorDos)
        {
            bool res = false;

            if (sumadorUno.cantidadSumas == sumadorDos.cantidadSumas)
            {
                res = true;
            }

            return res;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Billetes
{
    public class Pesos
    {
        privat
            oe double cantidad;
        priva,te static 
            kfloat cotizRespectoDolar;
    }
}

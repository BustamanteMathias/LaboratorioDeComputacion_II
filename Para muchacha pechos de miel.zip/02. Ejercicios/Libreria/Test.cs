﻿using System;

namespace Libreria
{
    public class Test
    {
        public static string Saludar()
        {
            string saludo = "HOLA MUNDO, DESDE LIBRERIA";

            return saludo;
        }
    }
}

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Clase_06
{
    public class Tempera
    {
    private ConsoleColor _color;
    private string _marca;
    private sbyte _cantidad;

    public Tempera(ConsoleColor color, string marca, sbyte cantidad)
    {
      this._color = color;
      this._marca = marca;
      this._cantidad = cantidad;
    }

    private string Mostrar()
    {
      String s = "Cantidad: " + this._cantidad + " Color: " + this._color + " Marca: "+ this._marca ;

      return s;
    }

    public static string Mostrar (Tempera t)
    {
      return t.Mostrar();
    }

    public static bool operator ==(Tempera t1, Tempera t2) //MARCA Y COLOR
    {
      bool r = false;

      if (t1 != null && t2 !=  null)
      {
        if (t1._color == t2._color && t1._marca == t2._marca)
        {
          r = true;
        }
      }

      return r;
    }

    public static bool operator !=(Tempera t1, Tempera t2)
    {
      bool r = !(t1 == t2);

      return r;
    }

    public static Tempera operator +(Tempera t1, sbyte cantidad) // ACUMULA CANTIDAD
    {
      Tempera temAux = t1;
      temAux._cantidad += cantidad;

      return temAux;
    }

    public static Tempera operator +(Tempera t1, Tempera t2)
    {
      Tempera temAux = t1;

      if (t1 == t2)
      {
        temAux._cantidad += t2._cantidad;
      }

      return temAux;
    }

    public static implicit operator sbyte (Tempera t)
    {
      sbyte r = t._cantidad;
      return r;
    }

  }
}

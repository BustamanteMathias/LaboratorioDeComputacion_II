using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bustamante.Mathias._2D
{
  public class SistemaSolar
  {
    #region ATRIBUTOS

    private List<Astro> planetas;
    #endregion

    #region PROPIEDADES

    public List<Astro> Planetas { get { return this.planetas; } }
    #endregion

    #region CONSTRUCTOR

    private SistemaSolar()
    {
      this.planetas = new List<Astro>();
    }
    #endregion

    #region METODOS

    public string MostrarInformacionAstros()
    {
      StringBuilder s = new StringBuilder();

      if (!Equals(Planetas, null))
      {
        foreach (Planeta planeta in this.Planetas)
        {
          s.AppendLine(planeta.ToString());

          foreach (Satelite satelite in planeta.Satelites)
          {
            s.AppendLine(satelite.ToString());
          }
        }
      }

      return s.ToString();
    }
    #endregion
  }
}

public enum Tipo { Rocoso, Gaseoso}

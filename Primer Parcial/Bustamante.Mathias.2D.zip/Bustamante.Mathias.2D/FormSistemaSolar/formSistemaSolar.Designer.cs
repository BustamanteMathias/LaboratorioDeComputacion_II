﻿namespace FormSistemaSolar
{
  partial class formSistemaSolar
  {
    /// <summary>
    /// Variable del diseñador necesaria.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Limpiar los recursos que se estén usando.
    /// </summary>
    /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
    protected override void Dispose(bool disposing)
    {
      if (disposing && (components != null))
      {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Código generado por el Diseñador de Windows Forms

    /// <summary>
    /// Método necesario para admitir el Diseñador. No se puede modificar
    /// el contenido de este método con el editor de código.
    /// </summary>
    private void InitializeComponent()
    {
            this.txtNombrePlaneta = new System.Windows.Forms.Label();
            this.txtOrbitaPlanera = new System.Windows.Forms.Label();
            this.cbmNombrePlaneta = new System.Windows.Forms.TextBox();
            this.cbmTiempoOrbita = new System.Windows.Forms.TextBox();
            this.txtPlaneta = new System.Windows.Forms.Label();
            this.txtNombreSatelite = new System.Windows.Forms.Label();
            this.cmbNombreSatelite = new System.Windows.Forms.TextBox();
            this.cmbPlaneta = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.cmbTipo = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.numSatelite = new System.Windows.Forms.NumericUpDown();
            this.numOrbita = new System.Windows.Forms.NumericUpDown();
            this.numRotacion = new System.Windows.Forms.NumericUpDown();
            this.btnAgregarPlaneta = new System.Windows.Forms.Button();
            this.btnAgregarSatelite = new System.Windows.Forms.Button();
            this.btnMostrarInformacion = new System.Windows.Forms.Button();
            this.btnMoverAstros = new System.Windows.Forms.Button();
            this.listado = new System.Windows.Forms.ListBox();
            this.cmbTiempoRotacion = new System.Windows.Forms.NumericUpDown();
            ((System.ComponentModel.ISupportInitialize)(this.numSatelite)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numOrbita)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numRotacion)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cmbTiempoRotacion)).BeginInit();
            this.SuspendLayout();
            // 
            // txtNombrePlaneta
            // 
            this.txtNombrePlaneta.AutoSize = true;
            this.txtNombrePlaneta.Location = new System.Drawing.Point(12, 15);
            this.txtNombrePlaneta.Name = "txtNombrePlaneta";
            this.txtNombrePlaneta.Size = new System.Drawing.Size(100, 13);
            this.txtNombrePlaneta.TabIndex = 0;
            this.txtNombrePlaneta.Text = "Nombre del Planeta";
            // 
            // txtOrbitaPlanera
            // 
            this.txtOrbitaPlanera.AutoSize = true;
            this.txtOrbitaPlanera.Location = new System.Drawing.Point(12, 42);
            this.txtOrbitaPlanera.Name = "txtOrbitaPlanera";
            this.txtOrbitaPlanera.Size = new System.Drawing.Size(137, 13);
            this.txtOrbitaPlanera.TabIndex = 1;
            this.txtOrbitaPlanera.Text = "Tiempo en completar Orbita";
            // 
            // cbmNombrePlaneta
            // 
            this.cbmNombrePlaneta.Location = new System.Drawing.Point(165, 12);
            this.cbmNombrePlaneta.Name = "cbmNombrePlaneta";
            this.cbmNombrePlaneta.Size = new System.Drawing.Size(193, 20);
            this.cbmNombrePlaneta.TabIndex = 2;
            // 
            // cbmTiempoOrbita
            // 
            this.cbmTiempoOrbita.Location = new System.Drawing.Point(165, 38);
            this.cbmTiempoOrbita.Name = "cbmTiempoOrbita";
            this.cbmTiempoOrbita.Size = new System.Drawing.Size(193, 20);
            this.cbmTiempoOrbita.TabIndex = 3;
            // 
            // txtPlaneta
            // 
            this.txtPlaneta.AutoSize = true;
            this.txtPlaneta.Location = new System.Drawing.Point(383, 15);
            this.txtPlaneta.Name = "txtPlaneta";
            this.txtPlaneta.Size = new System.Drawing.Size(43, 13);
            this.txtPlaneta.TabIndex = 4;
            this.txtPlaneta.Text = "Planeta";
            // 
            // txtNombreSatelite
            // 
            this.txtNombreSatelite.AutoSize = true;
            this.txtNombreSatelite.Location = new System.Drawing.Point(383, 42);
            this.txtNombreSatelite.Name = "txtNombreSatelite";
            this.txtNombreSatelite.Size = new System.Drawing.Size(99, 13);
            this.txtNombreSatelite.TabIndex = 5;
            this.txtNombreSatelite.Text = "Nombre del Satelite";
            // 
            // cmbNombreSatelite
            // 
            this.cmbNombreSatelite.Location = new System.Drawing.Point(547, 39);
            this.cmbNombreSatelite.Name = "cmbNombreSatelite";
            this.cmbNombreSatelite.Size = new System.Drawing.Size(193, 20);
            this.cmbNombreSatelite.TabIndex = 6;
            // 
            // cmbPlaneta
            // 
            this.cmbPlaneta.FormattingEnabled = true;
            this.cmbPlaneta.Location = new System.Drawing.Point(547, 12);
            this.cmbPlaneta.Name = "cmbPlaneta";
            this.cmbPlaneta.Size = new System.Drawing.Size(193, 21);
            this.cmbPlaneta.TabIndex = 7;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 69);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(152, 13);
            this.label1.TabIndex = 8;
            this.label1.Text = "Tiempo en completar Rotacion";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(16, 95);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(96, 13);
            this.label2.TabIndex = 9;
            this.label2.Text = "Cantidad de Lunas";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(16, 122);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(82, 13);
            this.label3.TabIndex = 10;
            this.label3.Text = "Tipo de Planeta";
            // 
            // cmbTipo
            // 
            this.cmbTipo.FormattingEnabled = true;
            this.cmbTipo.Location = new System.Drawing.Point(165, 119);
            this.cmbTipo.Name = "cmbTipo";
            this.cmbTipo.Size = new System.Drawing.Size(193, 21);
            this.cmbTipo.TabIndex = 11;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(383, 69);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(148, 13);
            this.label4.TabIndex = 12;
            this.label4.Text = "Tiempo en completar la Orbita";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(383, 95);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(163, 13);
            this.label5.TabIndex = 13;
            this.label5.Text = "Tiempo en completar la Rotacion";
            // 
            // numSatelite
            // 
            this.numSatelite.Location = new System.Drawing.Point(165, 93);
            this.numSatelite.Name = "numSatelite";
            this.numSatelite.Size = new System.Drawing.Size(193, 20);
            this.numSatelite.TabIndex = 15;
            // 
            // numOrbita
            // 
            this.numOrbita.Location = new System.Drawing.Point(547, 66);
            this.numOrbita.Name = "numOrbita";
            this.numOrbita.Size = new System.Drawing.Size(193, 20);
            this.numOrbita.TabIndex = 16;
            // 
            // numRotacion
            // 
            this.numRotacion.Location = new System.Drawing.Point(547, 93);
            this.numRotacion.Name = "numRotacion";
            this.numRotacion.Size = new System.Drawing.Size(193, 20);
            this.numRotacion.TabIndex = 17;
            // 
            // btnAgregarPlaneta
            // 
            this.btnAgregarPlaneta.Location = new System.Drawing.Point(15, 146);
            this.btnAgregarPlaneta.Name = "btnAgregarPlaneta";
            this.btnAgregarPlaneta.Size = new System.Drawing.Size(343, 38);
            this.btnAgregarPlaneta.TabIndex = 18;
            this.btnAgregarPlaneta.Text = "AGREGAR PLANETA";
            this.btnAgregarPlaneta.UseVisualStyleBackColor = true;
            this.btnAgregarPlaneta.Click += new System.EventHandler(this.btnAgregarPlaneta_Click);
            // 
            // btnAgregarSatelite
            // 
            this.btnAgregarSatelite.Location = new System.Drawing.Point(397, 146);
            this.btnAgregarSatelite.Name = "btnAgregarSatelite";
            this.btnAgregarSatelite.Size = new System.Drawing.Size(343, 38);
            this.btnAgregarSatelite.TabIndex = 19;
            this.btnAgregarSatelite.Text = "AGREGAR SATELITE";
            this.btnAgregarSatelite.UseVisualStyleBackColor = true;
            // 
            // btnMostrarInformacion
            // 
            this.btnMostrarInformacion.Location = new System.Drawing.Point(15, 194);
            this.btnMostrarInformacion.Name = "btnMostrarInformacion";
            this.btnMostrarInformacion.Size = new System.Drawing.Size(725, 38);
            this.btnMostrarInformacion.TabIndex = 20;
            this.btnMostrarInformacion.Text = "MOSTRAR INFORMACION";
            this.btnMostrarInformacion.UseVisualStyleBackColor = true;
            // 
            // btnMoverAstros
            // 
            this.btnMoverAstros.Location = new System.Drawing.Point(15, 238);
            this.btnMoverAstros.Name = "btnMoverAstros";
            this.btnMoverAstros.Size = new System.Drawing.Size(725, 38);
            this.btnMoverAstros.TabIndex = 21;
            this.btnMoverAstros.Text = "MOVER ASTROS";
            this.btnMoverAstros.UseVisualStyleBackColor = true;
            // 
            // listado
            // 
            this.listado.FormattingEnabled = true;
            this.listado.Location = new System.Drawing.Point(746, 12);
            this.listado.Name = "listado";
            this.listado.Size = new System.Drawing.Size(255, 264);
            this.listado.TabIndex = 22;
            // 
            // cmbTiempoRotacion
            // 
            this.cmbTiempoRotacion.Location = new System.Drawing.Point(165, 67);
            this.cmbTiempoRotacion.Name = "cmbTiempoRotacion";
            this.cmbTiempoRotacion.Size = new System.Drawing.Size(193, 20);
            this.cmbTiempoRotacion.TabIndex = 23;
            // 
            // formSistemaSolar
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1013, 281);
            this.Controls.Add(this.cmbTiempoRotacion);
            this.Controls.Add(this.listado);
            this.Controls.Add(this.btnMoverAstros);
            this.Controls.Add(this.btnMostrarInformacion);
            this.Controls.Add(this.btnAgregarSatelite);
            this.Controls.Add(this.btnAgregarPlaneta);
            this.Controls.Add(this.numRotacion);
            this.Controls.Add(this.numOrbita);
            this.Controls.Add(this.numSatelite);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.cmbTipo);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.cmbPlaneta);
            this.Controls.Add(this.cmbNombreSatelite);
            this.Controls.Add(this.txtNombreSatelite);
            this.Controls.Add(this.txtPlaneta);
            this.Controls.Add(this.cbmTiempoOrbita);
            this.Controls.Add(this.cbmNombrePlaneta);
            this.Controls.Add(this.txtOrbitaPlanera);
            this.Controls.Add(this.txtNombrePlaneta);
            this.Name = "formSistemaSolar";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.formSistemaSolar_Load);
            ((System.ComponentModel.ISupportInitialize)(this.numSatelite)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numOrbita)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numRotacion)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cmbTiempoRotacion)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

    }

    #endregion

    private System.Windows.Forms.Label txtNombrePlaneta;
    private System.Windows.Forms.Label txtOrbitaPlanera;
    private System.Windows.Forms.TextBox cbmNombrePlaneta;
    private System.Windows.Forms.TextBox cbmTiempoOrbita;
    private System.Windows.Forms.Label txtPlaneta;
    private System.Windows.Forms.Label txtNombreSatelite;
    private System.Windows.Forms.TextBox cmbNombreSatelite;
    private System.Windows.Forms.ComboBox cmbPlaneta;
    private System.Windows.Forms.Label label1;
    private System.Windows.Forms.Label label2;
    private System.Windows.Forms.Label label3;
    private System.Windows.Forms.ComboBox cmbTipo;
    private System.Windows.Forms.Label label4;
    private System.Windows.Forms.Label label5;
    private System.Windows.Forms.NumericUpDown numSatelite;
    private System.Windows.Forms.NumericUpDown numOrbita;
    private System.Windows.Forms.NumericUpDown numRotacion;
    private System.Windows.Forms.Button btnAgregarPlaneta;
    private System.Windows.Forms.Button btnAgregarSatelite;
    private System.Windows.Forms.Button btnMostrarInformacion;
    private System.Windows.Forms.Button btnMoverAstros;
    private System.Windows.Forms.ListBox listado;
    private System.Windows.Forms.NumericUpDown cmbTiempoRotacion;
  }
}


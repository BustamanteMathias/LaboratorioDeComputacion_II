using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Bustamante.Mathias._2D;

namespace FormSistemaSolar
{
  public partial class formSistemaSolar : Form
  {
    #region ATRIBUTOS

    public static List<Astro> planetas; 
    #endregion

    #region CONSTRUCTORES

    static formSistemaSolar()
    {
      formSistemaSolar.planetas = new List<Astro>();
    }

    public formSistemaSolar()
    {
      InitializeComponent();
    }
    #endregion

    #region EVENTOS

    private void formSistemaSolar_Load(object sender, EventArgs e)
    {
      this.Text = "Bustamante Mathias 2D";
      this.cmbTipo.Items.Add(Tipo.Gaseoso.ToString());
      this.cmbTipo.Items.Add(Tipo.Rocoso.ToString());
    }

    private void btnAgregarPlaneta_Click(object sender, EventArgs e)
    {
      Planeta p;

      string nombrePlaneta = "" + this.cbmNombrePlaneta.Text;
      string tiempoEnCompletarOrbita = "" + this.cbmTiempoOrbita.Text;
      string tiempoEnCompletarRotacion = "" + this.cmbTiempoRotacion.Text;
      string numeroDeSatelites = "" + this.numSatelite.Text;
      string tipoPlaneta = "" + this.cmbTipo.Text;
      string info = "";

      if (nombrePlaneta != "" && tiempoEnCompletarOrbita != "" && tiempoEnCompletarRotacion != "" && tipoPlaneta != "")
      {
        int tiempoOrbita;
        int satelites;
        int tiempoRotacion;
        if (int.TryParse(tiempoEnCompletarOrbita, out tiempoOrbita) && int.TryParse(numeroDeSatelites, out satelites))
        {
          //p = new Planeta(tiempoOrbita, (int)this.cmbTiempoRotacion, nombrePlaneta, satelites, (Tipo)this.cmbTipo.SelectedItem);
          info = p.ToString();
          //MessageBox.Show(p.ToString());
        }
      }
      else
      {
        info = "ERROR. NO DEJAR CAMPOS VACIOS AL CREAR PLANETA";
      }

      this.listado.Items.Add(info);
    } 
    #endregion
  }
}

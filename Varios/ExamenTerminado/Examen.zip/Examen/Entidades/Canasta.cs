using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
  public class Canasta<T> where T : IVegetales
  {
    #region ATRIBUTOS
    private List<T> plantas;
    private short capacidad;
    #endregion

    #region CONSTRUCTORES
    private Canasta()
    {
      this.plantas = new List<T>(this.capacidad);
    }

    public Canasta(short capacidad) : this()
    {
      this.capacidad = capacidad;
    }
    #endregion

    #region METODOS
    public static Canasta<T> operator +(Canasta<T> c, ReinoVegetal reinoVegetal)
    {
      if (reinoVegetal is T)
      {
        if (c.plantas.Count < c.capacidad)
        {
          T aux = (T)Convert.ChangeType(reinoVegetal, typeof(T));
          c.plantas.Add(aux);
        }
        else
        {
          throw new CapacidadExcedidaException();
        }
      }
      else
      {
        // Lanzar excepción con el mensaje "El elemento es del tipo {0}. Se esperaba {1}."

        // throw new ElementoException(string.Format("El elemento es del tipo {0}. Se esperaba {1}.", reinoVegetal.GetType(), c.GetType()));
      }

      return c;
    }

    public override string ToString()
    {
      StringBuilder sb = new StringBuilder();
      sb.AppendLine("Capacidad: " + this.capacidad);

      foreach (T reinoVegetal in this.plantas)
      {
        sb.AppendLine(reinoVegetal.MostrarDatos());
      }

      return sb.ToString();
    } 
    #endregion
  }
}

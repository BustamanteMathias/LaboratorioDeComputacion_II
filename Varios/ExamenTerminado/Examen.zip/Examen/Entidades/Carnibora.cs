using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
  public class Carnibora : ReinoVegetal, IVegetales
  {
    #region ATRIBUTOS
    public enum Captura { Pinzas, Pelos, Caída, Mecánicas, Combinada }

    private Captura tipo;
    private int tamanio;
    #endregion

    #region PROPIEDADES
    public Captura Tipo { get { return this.tipo; } set { this.tipo = value; } }
    public int Tamanio { get { return this.tamanio; } set { this.tamanio = value; } }
    #endregion

    #region CONSTRUCTOR
    public Carnibora(float valor, Gusto gusto, Captura tipo) : base(valor, gusto)
    {
      this.tipo = tipo;
    }

    public Carnibora(float valor, Gusto gusto, Captura tipo, int tamanio) : this(valor, gusto, tipo)
    {
      this.tamanio = tamanio;
    }
    #endregion

    #region METODOS
    public override string MostrarDatos()
    {
      return String.Format("Carnibora Tam: {0}. Valor: {1}. Gusto: {2}. Tipo: {3}", this.tamanio, this.valor, this.gusto, this.tipo.ToString());
    }
    #endregion
  }
}

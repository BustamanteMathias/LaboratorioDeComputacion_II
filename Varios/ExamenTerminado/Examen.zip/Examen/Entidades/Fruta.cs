using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Entidades
{
  [Serializable]
  public class Fruta : ReinoVegetal, IVegetales
  {
    #region ATRIBUTOS
    private ConsoleColor color; 
    #endregion

    #region PROPIEDADES
    public ConsoleColor Color { get { return this.color; } set { this.color = value; } }
    #endregion

    #region CONSTRUCTOR
    public Fruta(float valor, Gusto gusto, ConsoleColor color) : base(valor, gusto)
    {
      // Completar
      this.color = color;
    }
    #endregion

    #region METODOS
    public override string MostrarDatos()
    {
      return String.Format("Fruta color: {0}. Valor: {1}. Gusto: {2}.", this.color.ToString(), this.valor, this.gusto.ToString());
    } 
    #endregion
  }
}

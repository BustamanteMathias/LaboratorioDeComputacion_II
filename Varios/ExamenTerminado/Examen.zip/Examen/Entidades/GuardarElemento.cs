using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Entidades
{
  public static class GuardarElemento
  {
    #region METODOS DE EXTENSION
    public static string MostrarElemento(this Fruta fruta)
    {
      string pathEscritorio = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);

      try
      {
        //ARCHIVO TXT
        StreamWriter f = new StreamWriter(pathEscritorio + "\\Frutas.txt", true);
        f.WriteLine(fruta.MostrarDatos());
        f.Close();

        //ARCHIVO XML
        XmlSerializer serializer = new XmlSerializer(typeof(Fruta));

        FileStream fStream = File.Open(pathEscritorio + "\\Frutas", FileMode.Create);

        serializer.Serialize(fStream, fruta);

        fStream.Close();
      }
      catch (Exception)
      {
      }

      return fruta.MostrarDatos();
    } 
    #endregion
  }
}

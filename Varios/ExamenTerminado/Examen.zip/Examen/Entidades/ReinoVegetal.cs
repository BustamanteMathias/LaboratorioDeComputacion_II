using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
  public abstract class ReinoVegetal
  {
    #region ATRIBUTOS
    public enum Gusto { Dulce, Salado, Toxica }
    private static Random calcularValor;

    protected float valor;
    protected Gusto gusto;
    #endregion

    #region CONSTRUCTORES
    static ReinoVegetal()
    {
      ReinoVegetal.calcularValor = new Random();
    }
    public ReinoVegetal(Gusto gusto)
    {
      this.gusto = gusto;
      this.valor = calcularValor.Next(1, 100);
    }

    public ReinoVegetal(float valor, Gusto gusto)
    {
      this.valor = valor;
      this.gusto = gusto;
    }
    #endregion

    #region METODOS
    public static bool operator ==(ReinoVegetal v1, ReinoVegetal v2)
    {
      if (v1.gusto == v2.gusto)
      {
        if (v1.GetType() == v2.GetType())
        {
          return true;
        }
      }
      return false;
    }

    public static bool operator !=(ReinoVegetal v1, ReinoVegetal v2)
    {
      return !(v1 == v2);
    }

    public virtual string MostrarDatos()
    {
      return String.Format("Valor: {0}. Gusto{1}", this.valor, this.gusto);
    } 
    #endregion
  }
}

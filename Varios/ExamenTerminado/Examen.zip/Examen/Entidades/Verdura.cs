using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
  public class Verdura : ReinoVegetal, IVegetales
  {
    #region ATRIBUTOS
    public enum TipoVerdura { Semilla, Raíz, Tubérculo, Bulbo, Tallo, Hoja, Inflorescencia, Rizoma }

    private TipoVerdura tipo;
    #endregion

    #region PROPIEDADES
    public TipoVerdura Tipo { get { return this.tipo; } set { this.tipo = value; } } 
    #endregion

    #region CONSTRUCTOR
    public Verdura(float valor, Gusto gusto, TipoVerdura tipo) : base(valor, gusto)
    {
      // Completar
      this.tipo = tipo;
    }
    #endregion

    #region METODOS
    public override string MostrarDatos()
    {
      return String.Format("Tipo de Verdura: {0}. Valor: {1}. Gusto: {2}.", this.tipo.ToString(), this.valor, this.gusto.ToString());
    } 
    #endregion
  }
}

using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Entidades;

namespace TestUnitario
{
  [TestClass]
  public class TestUnitario
  {
    [TestMethod]
    public void NoAgregaException()
    {
      Fruta f1 = new Fruta(1.5f, ReinoVegetal.Gusto.Dulce, ConsoleColor.Blue);
      Fruta f2 = new Fruta(1.5f, ReinoVegetal.Gusto.Dulce, ConsoleColor.Blue);
      Fruta f3 = new Fruta(1.5f, ReinoVegetal.Gusto.Dulce, ConsoleColor.Blue);

      Canasta<Fruta> canasta = new Canasta<Fruta>(2);

      try
      {
        canasta += f1;
        canasta += f2;
        canasta += f3;
      }
      catch (NoAgregaException)
      {

      }
    }
  }
}
